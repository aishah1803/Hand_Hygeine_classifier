#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
import re
import sys
import threading
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from tempfile import NamedTemporaryFile

import cv2
import numpy as np

WEBSITE_ROOT = Path(__file__).resolve().parent
PIPELINE_ROOT = WEBSITE_ROOT.parent / "hand_hygiene_pipeline"
DEFAULT_CONFIG_PATH = (
    PIPELINE_ROOT / "runs" / "strict_hand_seg" / "experiment_val_0p09_cpu_best_config.json"
)
DEFAULT_WARMUP_IMAGE = (
    PIPELINE_ROOT
    / "data"
    / "strict_segmentation_yolo"
    / "images"
    / "val"
    / "382d32e3-Copy_of_20231003_142139.jpg"
)
UPLOAD_DIR = WEBSITE_ROOT / ".demo_uploads"
MAX_UPLOAD_BYTES = 8 * 1024 * 1024
VISIBLE_GEL_REGION_THRESHOLD = 0.03
MIN_VISIBLE_GEL_PIXELS = 40
ANNOTATED_MAX_WIDTH = 960
ANNOTATED_JPEG_QUALITY = 72
DATA_URL_RE = re.compile(r"^data:(image/[a-zA-Z0-9.+-]+);base64,(.+)$")
MIME_SUFFIX = {
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/png": ".png",
    "image/bmp": ".bmp",
    "image/webp": ".webp",
}

if str(PIPELINE_ROOT) not in sys.path:
    sys.path.insert(0, str(PIPELINE_ROOT))

from hand_hygiene_pipeline.config import PipelineConfig
from hand_hygiene_pipeline.data_models import StageFailure
from hand_hygiene_pipeline.pipeline import HandHygienePipeline

_PIPELINE_LOCK = threading.Lock()
_PIPELINE_INSTANCE: HandHygienePipeline | None = None


def _load_pipeline(config_path: Path) -> HandHygienePipeline:
    global _PIPELINE_INSTANCE
    with _PIPELINE_LOCK:
        if _PIPELINE_INSTANCE is not None:
            return _PIPELINE_INSTANCE

        config = PipelineConfig.from_json(config_path)
        config.log_dir = str((PIPELINE_ROOT / "runs" / "web_demo_logs").resolve())
        if not Path(config.segmentation.weights_path).is_absolute():
            config.segmentation.weights_path = str(
                (PIPELINE_ROOT / config.segmentation.weights_path).resolve()
            )
        if not Path(config.landmarks.model_asset_path).is_absolute():
            config.landmarks.model_asset_path = str(
                (PIPELINE_ROOT / config.landmarks.model_asset_path).resolve()
            )
        _PIPELINE_INSTANCE = HandHygienePipeline(config)
        return _PIPELINE_INSTANCE


def _warm_up_pipeline(config_path: Path) -> None:
    try:
        pipeline = _load_pipeline(config_path)
        if DEFAULT_WARMUP_IMAGE.exists():
            pipeline.process_image(DEFAULT_WARMUP_IMAGE)
            print(f"[demo] Warm-up completed with {DEFAULT_WARMUP_IMAGE.name}")
    except Exception as exc:  # pragma: no cover
        print(f"[demo] Warm-up skipped: {exc}")


def _decode_upload(payload: dict) -> tuple[bytes, str]:
    image_data = payload.get("imageData")
    if not isinstance(image_data, str):
        raise ValueError("Missing 'imageData' data URL.")

    match = DATA_URL_RE.match(image_data)
    if not match:
        raise ValueError("Unsupported image payload.")

    mime_type, encoded = match.groups()
    suffix = MIME_SUFFIX.get(mime_type.lower())
    if suffix is None:
        raise ValueError(f"Unsupported image type: {mime_type}")

    try:
        image_bytes = base64.b64decode(encoded, validate=True)
    except Exception as exc_info:  # pragma: no cover
        raise ValueError("Image payload could not be decoded.") from exc_info

    if not image_bytes:
        raise ValueError("Uploaded image was empty.")
    if len(image_bytes) > MAX_UPLOAD_BYTES:
        raise ValueError("Uploaded image is too large for the demo server.")
    return image_bytes, suffix


def _contamination_level(score: float) -> str:
    if score >= 0.75:
        return "Low"
    if score >= 0.50:
        return "Moderate"
    if score >= 0.25:
        return "High"
    return "Very High"


def _friendly_list(values: list[str]) -> str:
    if not values:
        return ""
    if len(values) == 1:
        return values[0]
    if len(values) == 2:
        return f"{values[0]} and {values[1]}"
    return f"{', '.join(values[:-1])}, and {values[-1]}"


def _build_summary_message(decision: str, score: float, failing_regions: list[str]) -> str:
    if decision == "Pass":
        return "Visible UV coverage met the current demo threshold across the analysed hand regions."
    if failing_regions:
        areas = _friendly_list(failing_regions[:3])
        return f"Lower visible coverage was detected around the {areas} regions."
    if score < 0.25:
        return "Visible contamination coverage appears widespread across the analysed hand."
    return "Visible UV coverage stayed below the current prototype pass threshold."


def _title_case_region(region_name: str) -> str:
    return region_name.replace("_", " ").title()


def _jpeg_data_url(image_bgr: np.ndarray) -> str | None:
    height, width = image_bgr.shape[:2]
    if width > ANNOTATED_MAX_WIDTH:
        scaled_height = int(round(height * (ANNOTATED_MAX_WIDTH / width)))
        image_bgr = cv2.resize(
            image_bgr,
            (ANNOTATED_MAX_WIDTH, max(scaled_height, 1)),
            interpolation=cv2.INTER_AREA,
        )
    success, encoded = cv2.imencode(
        ".jpg",
        image_bgr,
        [int(cv2.IMWRITE_JPEG_QUALITY), ANNOTATED_JPEG_QUALITY],
    )
    if not success:
        return None
    return "data:image/jpeg;base64," + base64.b64encode(encoded.tobytes()).decode("ascii")


def _build_visual_evidence(image_path: Path, pipeline: HandHygienePipeline) -> dict:
    image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if image_bgr is None:
        return {}

    frame_id = image_path.stem
    segmentation = pipeline.segmenter.segment(image_bgr, frame_id=frame_id)
    if isinstance(segmentation, StageFailure):
        return {}

    landmarks, _ = pipeline._detect_landmarks_with_fallback(
        image_bgr,
        segmentation,
        frame_id=frame_id,
    )
    if isinstance(landmarks, StageFailure):
        return {}

    focus_x1, focus_y1, focus_x2, focus_y2 = pipeline._focused_roi_bounds(
        segmentation.roi.shape[:2],
        landmarks,
    )
    focused_roi, focused_mask, focused_landmarks = pipeline._focus_roi_on_landmarks(
        segmentation.roi,
        segmentation.roi_mask,
        landmarks,
    )
    region_crops = pipeline.region_splitter.split(
        focused_roi,
        focused_landmarks,
        hand_mask=focused_mask,
    )
    if isinstance(region_crops, StageFailure):
        return {}

    region_results, gel_masks = pipeline.classifier.predict_with_masks(region_crops)
    overlay = image_bgr.copy()
    gel_regions: list[str] = []
    gel_region_scores: dict[str, float] = {}
    overlay_origin_x = segmentation.bbox[0] + focus_x1
    overlay_origin_y = segmentation.bbox[1] + focus_y1
    overlay_colour = np.array([20, 170, 255], dtype=np.uint8)

    for region_name, crop in region_crops.items():
        gel_mask = gel_masks.get(region_name)
        if gel_mask is None or gel_mask.size == 0:
            continue

        gel_pixels = int(np.count_nonzero(gel_mask))
        score = float(region_results[region_name].score)
        if gel_pixels < MIN_VISIBLE_GEL_PIXELS and score < VISIBLE_GEL_REGION_THRESHOLD:
            continue

        display_name = _title_case_region(region_name)
        gel_regions.append(display_name)
        gel_region_scores[display_name] = round(score * 100, 1)

        crop_x1, crop_y1, crop_x2, crop_y2 = crop.bbox
        full_x1 = overlay_origin_x + crop_x1
        full_y1 = overlay_origin_y + crop_y1
        full_x2 = overlay_origin_x + crop_x2
        full_y2 = overlay_origin_y + crop_y2

        full_x1 = max(0, min(full_x1, overlay.shape[1]))
        full_x2 = max(0, min(full_x2, overlay.shape[1]))
        full_y1 = max(0, min(full_y1, overlay.shape[0]))
        full_y2 = max(0, min(full_y2, overlay.shape[0]))
        if full_x2 <= full_x1 or full_y2 <= full_y1:
            continue

        target = overlay[full_y1:full_y2, full_x1:full_x2]
        mask = gel_mask[: target.shape[0], : target.shape[1]] > 0
        if not np.any(mask):
            continue

        tinted = np.tile(overlay_colour, (target.shape[0], target.shape[1], 1))
        target[mask] = cv2.addWeighted(target, 0.35, tinted, 0.65, 0)[mask]

        contours, _ = cv2.findContours(
            gel_mask[: target.shape[0], : target.shape[1]],
            cv2.RETR_EXTERNAL,
            cv2.CHAIN_APPROX_SIMPLE,
        )
        if not contours:
            continue

        largest = max(contours, key=cv2.contourArea)
        if cv2.contourArea(largest) < MIN_VISIBLE_GEL_PIXELS:
            continue

        contour_offset = largest + np.array([[[full_x1, full_y1]]], dtype=np.int32)
        cv2.drawContours(overlay, [contour_offset], -1, (0, 90, 220), 2, cv2.LINE_AA)
        box_x, box_y, _, _ = cv2.boundingRect(contour_offset)
        label = f"{display_name} gel"
        text_y = max(62, box_y - 8)
        cv2.putText(
            overlay,
            label,
            (box_x, text_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (255, 255, 255),
            2,
            cv2.LINE_AA,
        )

    annotated_image_data = _jpeg_data_url(overlay)
    if not gel_regions:
        return {
            "annotatedImageData": annotated_image_data,
            "visibleGelRegions": [],
            "visibleGelRegionScores": {},
        }

    gel_regions = sorted(dict.fromkeys(gel_regions))
    ordered_scores = {
        region_name: gel_region_scores[region_name]
        for region_name in gel_regions
    }
    return {
        "annotatedImageData": annotated_image_data,
        "visibleGelRegions": gel_regions,
        "visibleGelRegionScores": ordered_scores,
    }


def _failure_message(stage: str | None, reason: str | None) -> str:
    if stage == "decode":
        return "We could not read that file as a usable image. Try a clear JPG or PNG export, then upload it again."
    if stage == "segmentation":
        if reason in {"no_hand_detected", "low_confidence_or_wrong_class", "empty_mask", "no_result"}:
            return (
                "We could not clearly isolate one hand from that image. "
                "Try one UV image with a single open palm, the full hand in frame, and a plain darker background."
            )
    if stage == "landmarks":
        if reason in {
            "no_hand_landmarks",
            "low_landmark_confidence",
            "unexpected_landmark_count",
            "fallback_landmarks_outside_roi",
        }:
            return (
                "The hand was found, but finger landmarks were not stable enough to score it. "
                "Try a sharper image with the palm facing the camera and the fingers slightly separated."
            )
    if stage == "region_split":
        return (
            "The hand was detected, but the prototype could not split the palm and fingers cleanly. "
            "Try a clearer palm-up image with the full hand visible."
        )
    if stage == "classification":
        return "The prototype reached scoring but could not finish the UV coverage check for that image. Please try another image."
    if stage == "aggregation":
        return "The prototype produced intermediate scores but could not finish the final decision. Please try another image."
    return "We could not analyse that image. Try one UV image with a single open palm, the full hand in frame, and clear UV contrast."


def _result_payload(output) -> dict:
    if output.status != "processed" or output.aggregate is None:
        failure = output.failure
        return {
            "status": "unprocessable",
            "message": _failure_message(
                failure.stage if failure else None,
                failure.reason if failure else None,
            ),
            "failureStage": failure.stage if failure else None,
            "failureReason": failure.reason if failure else None,
            "details": failure.details if failure else {},
        }

    score = float(output.aggregate.overall_score)
    confidence = float(output.aggregate.overall_confidence)
    decision = "Pass" if output.aggregate.passed else "Fail"
    failing_regions = list(output.aggregate.failing_regions)
    region_scores = {
        region_name: round(result.score * 100, 1)
        for region_name, result in output.region_results.items()
    }
    payload = {
        "status": "processed",
        "message": _build_summary_message(decision, score, failing_regions),
        "decision": decision,
        "handHygieneScore": round(score * 100),
        "contaminationLevel": _contamination_level(score),
        "detectionConfidence": round(confidence * 100),
        "segmentationConfidence": round((output.segmentation_confidence or 0.0) * 100),
        "landmarkConfidence": round((output.landmark_confidence or 0.0) * 100),
        "areasNeedingAttention": failing_regions,
        "handedness": output.handedness,
        "landmarkMode": output.landmark_mode,
        "stageLatenciesMs": output.stage_latencies_ms,
        "regionScores": region_scores,
    }
    source_path = Path(output.source_image_path) if output.source_image_path else None
    if source_path is not None and source_path.exists():
        payload.update(_build_visual_evidence(source_path, _load_pipeline(DEFAULT_CONFIG_PATH)))
    else:
        payload.update(
            {
                "annotatedImageData": None,
                "visibleGelRegions": [],
                "visibleGelRegionScores": {},
            }
        )
    return payload


class DemoRequestHandler(SimpleHTTPRequestHandler):
    server_version = "HandHygieneDemo/0.1"

    def __init__(self, *args, directory: str | None = None, config_path: Path | None = None, **kwargs):
        self.config_path = config_path or DEFAULT_CONFIG_PATH
        super().__init__(*args, directory=directory or str(WEBSITE_ROOT), **kwargs)

    def log_message(self, format: str, *args) -> None:  # pragma: no cover
        print(f"[demo] {self.address_string()} - {format % args}")

    def do_GET(self) -> None:
        if self.path == "/api/health":
            self._send_json({"status": "ok"})
            return
        if self.path in {"", "/"}:
            self.path = "/index.html"
        super().do_GET()

    def do_POST(self) -> None:
        if self.path != "/api/analyse":
            self.send_error(HTTPStatus.NOT_FOUND, "Endpoint not found")
            return

        content_length = self.headers.get("Content-Length")
        if content_length is None:
            self._send_json({"error": "Missing Content-Length header."}, status=HTTPStatus.BAD_REQUEST)
            return
        if int(content_length) > MAX_UPLOAD_BYTES * 2:
            self._send_json(
                {"error": "Request body is too large for the demo server."},
                status=HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
            )
            return

        body = self.rfile.read(int(content_length))
        try:
            payload = json.loads(body.decode("utf-8"))
        except Exception:
            self._send_json({"error": "Request body must be JSON."}, status=HTTPStatus.BAD_REQUEST)
            return

        try:
            image_bytes, suffix = _decode_upload(payload)
        except ValueError as exc:
            self._send_json({"error": str(exc)}, status=HTTPStatus.BAD_REQUEST)
            return

        UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
        temp_path: Path | None = None
        try:
            with NamedTemporaryFile(dir=UPLOAD_DIR, suffix=suffix, delete=False) as temp_file:
                temp_file.write(image_bytes)
                temp_path = Path(temp_file.name)

            pipeline = _load_pipeline(self.config_path)
            output = pipeline.process_image(temp_path)
            self._send_json(_result_payload(output))
        except Exception as exc:  # pragma: no cover
            self._send_json(
                {
                    "status": "error",
                    "error": "The demo server hit an unexpected error while analysing that image.",
                    "details": str(exc),
                },
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
            )
        finally:
            if temp_path and temp_path.exists():
                temp_path.unlink(missing_ok=True)

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def guess_type(self, path: str) -> str:
        if path.endswith(".js"):
            return "text/javascript"
        return mimetypes.guess_type(path)[0] or "application/octet-stream"

    def _send_json(self, payload: dict, *, status: HTTPStatus = HTTPStatus.OK) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main() -> int:
    parser = argparse.ArgumentParser(description="Local web demo for the hand hygiene pipeline.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG_PATH))
    parser.add_argument("--no-warmup", action="store_true")
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    if not config_path.exists():
        raise SystemExit(f"Config not found: {config_path}")

    if not args.no_warmup:
        _warm_up_pipeline(config_path)

    handler = partial(
        DemoRequestHandler,
        directory=str(WEBSITE_ROOT),
        config_path=config_path,
    )
    with ThreadingHTTPServer((args.host, args.port), handler) as httpd:
        print(f"[demo] Serving website at http://{args.host}:{args.port}")
        print(f"[demo] Using config: {config_path}")
        httpd.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
