# UV Hand Hygiene Demo Website

This folder contains a lightweight local demo website for the hand hygiene pipeline.

## What it does

- Serves a simple upload website
- Accepts one UV hand image at a time
- Runs the Python hand hygiene pipeline
- Returns:
  - `Hand Hygiene Score`
  - `Contamination Level`
  - `Pass / Fail`

## How to run

From the pipeline virtual environment:

```bash
cd /Users/ericsvzn/Documents/Hand_Classification_Python/hand_hygiene_pipeline
./.venv/bin/python /Users/ericsvzn/Documents/Hand_Classification_Python/hand-hygiene-website-main/demo_server.py --host 127.0.0.1 --port 8000
```

Then open:

```text
http://127.0.0.1:8000
```

## Notes

- The server warms up the pipeline on startup to reduce first-request delay during the class demo.
- The default backend config is:
  - `runs/strict_hand_seg/experiment_val_0p09_cpu_best_config.json`
- Demo logs are written to:
  - `hand_hygiene_pipeline/runs/web_demo_logs`

## Demo-safe wording

- `Hand Hygiene Score`
- `Contamination Level`
- `Pass / Fail`

This is a presentation prototype, not a clinical diagnostic tool.
