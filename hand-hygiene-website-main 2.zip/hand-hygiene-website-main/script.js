const state = {
  file: null,
  imageData: null,
};

const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;
const ANALYSIS_TIMEOUT_MS = 45000;
const SLOW_REQUEST_NOTICE_MS = 8000;
const ALLOWED_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/bmp",
  "image/webp",
]);

const imageInput = document.getElementById("image-input");
const dropzone = document.getElementById("dropzone");
const analyseButton = document.getElementById("analyse-button");
const resetButton = document.getElementById("reset-button");
const statusBanner = document.getElementById("status-banner");
const previewCard = document.getElementById("preview-card");
const fileName = document.getElementById("file-name");
const imagePreview = document.getElementById("image-preview");

const resultEmpty = document.getElementById("result-empty");
const resultLoading = document.getElementById("result-loading");
const resultError = document.getElementById("result-error");
const resultReady = document.getElementById("result-ready");

const errorMessage = document.getElementById("error-message");
const decisionChip = document.getElementById("decision-chip");
const resultSummary = document.getElementById("result-summary");
const analysisImage = document.getElementById("analysis-image");
const analysisCaption = document.getElementById("analysis-caption");
const scoreValue = document.getElementById("score-value");
const contaminationValue = document.getElementById("contamination-value");
const confidenceValue = document.getElementById("confidence-value");
const areasValue = document.getElementById("areas-value");
const handednessValue = document.getElementById("handedness-value");
const landmarkModeValue = document.getElementById("landmark-mode-value");
const regionBars = document.getElementById("region-bars");
const latencyGrid = document.getElementById("latency-grid");

function setStatus(message, tone = "neutral") {
  statusBanner.textContent = message;
  statusBanner.dataset.tone = tone;
}

function showResultState(kind) {
  resultEmpty.hidden = kind !== "empty";
  resultLoading.hidden = kind !== "loading";
  resultError.hidden = kind !== "error";
  resultReady.hidden = kind !== "ready";
}

function resetResultView() {
  showResultState("empty");
  decisionChip.textContent = "Pending";
  decisionChip.dataset.decision = "";
  resultSummary.textContent = "";
  analysisImage.removeAttribute("src");
  analysisCaption.textContent = "Highlighted pixels show where the prototype detected visible gel within the analysed hand regions.";
  scoreValue.textContent = "--";
  contaminationValue.textContent = "--";
  confidenceValue.textContent = "--";
  areasValue.textContent = "None.";
  handednessValue.textContent = "--";
  landmarkModeValue.textContent = "--";
  regionBars.innerHTML = "";
  latencyGrid.innerHTML = "";
}

function resetUpload() {
  state.file = null;
  state.imageData = null;
  imageInput.value = "";
  previewCard.hidden = true;
  imagePreview.removeAttribute("src");
  fileName.textContent = "No file selected";
  analyseButton.disabled = true;
  resetResultView();
  setStatus("Ready for a UV hand image.");
}

async function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Could not read the selected file."));
    reader.readAsDataURL(file);
  });
}

async function handleFile(file) {
  if (!file) {
    setStatus("Please choose one image file.", "error");
    return;
  }

  if (!ALLOWED_TYPES.has(file.type)) {
    setStatus("Please use a JPG, PNG, BMP, or WEBP image.", "error");
    renderErrorResult({
      message: "That file type is not supported for this demo. Export the image as JPG or PNG, then try again.",
    });
    return;
  }

  if (file.size > MAX_UPLOAD_BYTES) {
    setStatus("That image is larger than 8 MB.", "error");
    renderErrorResult({
      message: "That image is too large for the demo server. Save it as a smaller JPG or PNG, then try again.",
    });
    return;
  }

  state.file = file;
  state.imageData = await fileToDataUrl(file);
  fileName.textContent = `${file.name} · ${(file.size / 1024 / 1024).toFixed(2)} MB`;
  imagePreview.src = state.imageData;
  previewCard.hidden = false;
  analyseButton.disabled = false;
  resetResultView();
  setStatus("Image selected. Review it, then run the hygiene check.", "success");
}

function renderRegionBars(regionScores = {}) {
  regionBars.innerHTML = "";
  Object.entries(regionScores).forEach(([region, score]) => {
    const row = document.createElement("div");
    row.className = "region-row";

    const label = document.createElement("span");
    label.className = "region-label";
    label.textContent = region;

    const barTrack = document.createElement("div");
    barTrack.className = "region-track";

    const barFill = document.createElement("div");
    barFill.className = "region-fill";
    barFill.style.width = `${Math.max(6, score)}%`;

    const value = document.createElement("span");
    value.className = "region-value";
    value.textContent = `${score.toFixed(1)}%`;

    barTrack.appendChild(barFill);
    row.append(label, barTrack, value);
    regionBars.appendChild(row);
  });
}

function renderLatency(latencies = {}) {
  latencyGrid.innerHTML = "";
  const preferredOrder = ["decode", "segmentation", "landmarks", "region_split", "classification", "aggregation", "total"];
  preferredOrder.forEach((key) => {
    if (!(key in latencies)) {
      return;
    }
    const item = document.createElement("div");
    item.className = "latency-item";

    const label = document.createElement("span");
    label.className = "latency-label";
    label.textContent = key.replace("_", " ");

    const value = document.createElement("strong");
    value.className = "latency-value";
    value.textContent = `${Number(latencies[key]).toFixed(1)} ms`;

    item.append(label, value);
    latencyGrid.appendChild(item);
  });
}

function renderProcessedResult(result) {
  decisionChip.textContent = result.decision;
  decisionChip.dataset.decision = result.decision.toLowerCase();
  resultSummary.textContent = result.message;
  if (result.annotatedImageData) {
    analysisImage.src = result.annotatedImageData;
  } else if (state.imageData) {
    analysisImage.src = state.imageData;
  }
  scoreValue.textContent = `${result.handHygieneScore}%`;
  contaminationValue.textContent = result.contaminationLevel;
  confidenceValue.textContent = `${result.detectionConfidence}%`;
  const gelRegions = Array.isArray(result.visibleGelRegions) ? result.visibleGelRegions : [];
  const gelScores = result.visibleGelRegionScores || {};
  areasValue.textContent = gelRegions.length
    ? gelRegions.map((region) => `${region} (${Number(gelScores[region] || 0).toFixed(1)}%)`).join(", ")
    : "No strong visible gel region was highlighted.";
  analysisCaption.textContent = gelRegions.length
    ? `Highlighted pixels indicate where visible gel was detected in: ${gelRegions.join(", ")}.`
    : "No region crossed the visible-gel highlight threshold in this image.";
  handednessValue.textContent = result.handedness ? `Detected hand: ${result.handedness}` : "Detected hand: unknown";
  landmarkModeValue.textContent = result.landmarkMode
    ? `Tracking mode: ${formatLandmarkMode(result.landmarkMode)}`
    : "Tracking mode: unavailable";
  renderRegionBars(result.regionScores);
  renderLatency(result.stageLatenciesMs);
  showResultState("ready");
}

function renderErrorResult(result) {
  errorMessage.textContent = result.message || "We could not analyse that image.";
  showResultState("error");
}

async function analyseImage() {
  if (!state.file || !state.imageData) {
    setStatus("Choose one UV image first.", "error");
    return;
  }

  showResultState("loading");
  analyseButton.disabled = true;
  setStatus("Running prototype analysis...", "loading");
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), ANALYSIS_TIMEOUT_MS);
  const slowNoticeId = window.setTimeout(() => {
    setStatus("Still working... the first run can take a little longer on this machine.", "loading");
  }, SLOW_REQUEST_NOTICE_MS);

  try {
    const response = await fetch("/api/analyse", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      signal: controller.signal,
      body: JSON.stringify({
        filename: state.file.name,
        imageData: state.imageData,
      }),
    });

    const payload = await response.json();
    if (!response.ok) {
      throw new Error(payload.error || "The demo server could not analyse this image.");
    }

    if (payload.status === "processed") {
      renderProcessedResult(payload);
      setStatus("Assessment complete.", "success");
      return;
    }

    renderErrorResult(payload);
    setStatus(payload.message || "That image needs another try.", "error");
  } catch (error) {
    if (error.name === "AbortError") {
      errorMessage.textContent = "The hygiene check took too long to finish. Please try the image again or use a smaller, clearer file.";
      showResultState("error");
      setStatus("The hygiene check timed out.", "error");
      return;
    }
    errorMessage.textContent = error.message || "Unexpected error during analysis.";
    showResultState("error");
    setStatus(error.message || "The demo server hit an error.", "error");
  } finally {
    window.clearTimeout(timeoutId);
    window.clearTimeout(slowNoticeId);
    analyseButton.disabled = false;
  }
}

function formatLandmarkMode(mode) {
  const labels = {
    roi: "standard crop",
    bbox_crop_fallback: "crop recovery",
    full_image_fallback: "full image recovery",
  };
  return labels[mode] || mode.replaceAll("_", " ");
}

imageInput.addEventListener("change", async (event) => {
  const [file] = event.target.files;
  if (file) {
    await handleFile(file);
  }
});

dropzone.addEventListener("dragover", (event) => {
  event.preventDefault();
  dropzone.dataset.drag = "active";
});

dropzone.addEventListener("dragleave", () => {
  dropzone.dataset.drag = "idle";
});

dropzone.addEventListener("drop", async (event) => {
  event.preventDefault();
  dropzone.dataset.drag = "idle";
  const [file] = event.dataTransfer.files;
  if (file) {
    await handleFile(file);
  }
});

analyseButton.addEventListener("click", analyseImage);
resetButton.addEventListener("click", resetUpload);

resetUpload();
