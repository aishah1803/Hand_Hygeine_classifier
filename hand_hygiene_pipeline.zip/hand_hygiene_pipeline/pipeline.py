from __future__ import annotations
from pathlib import Path

import cv2  # type: ignore

from .aggregation import ScoreAggregator
from .gel_detector import GelCoverageEstimator
from .config import PipelineConfig
from .data_models import LandmarkOutput, LandmarkPoint, PipelineOutput, SegmentationOutput, StageFailure
from .landmarks import MediaPipeHandLandmarkDetector
from .profiling import PipelineLogger, StageProfiler
from .regions import AnatomicalRegionSplitter
from .segmentation import HandSegmenter


class HandHygienePipeline:
    def __init__(self, config: PipelineConfig) -> None:
        self.config = config
        self.logger = PipelineLogger(
            config.log_dir,
            prediction_log_name=config.prediction_log_name,
            prediction_csv_log_name=config.prediction_csv_log_name,
            latency_log_name=config.latency_log_name,
        )
        self.segmenter = HandSegmenter(config.segmentation)
        self.landmarker = MediaPipeHandLandmarkDetector(config.landmarks)
        self.region_splitter = AnatomicalRegionSplitter(config.regions)
        self.classifier = GelCoverageEstimator(config.gel_detection)
        self.aggregator = ScoreAggregator(config.aggregation)

    def process_image(self, image_path: str | Path) -> PipelineOutput:
        image_path = Path(image_path).resolve()
        frame_id = image_path.stem
        profiler = StageProfiler()

        with profiler.measure("decode"):
            image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image_bgr is None:
            output = PipelineOutput(
                frame_id=frame_id,
                status="unprocessable",
                stage_latencies_ms=profiler.latencies_ms,
                source_image_path=str(image_path),
                failure=StageFailure("decode", "unreadable_image", {"image_path": str(image_path)}),
            )
            self.logger.log_failure(
                "decode",
                frame_id=frame_id,
                reason="unreadable_image",
                details={"image_path": str(image_path)},
                latencies_ms=profiler.latencies_ms,
            )
            self.logger.log_output(output)
            return output

        with profiler.measure("segmentation"):
            segmentation = self.segmenter.segment(image_bgr, frame_id=frame_id)
        if isinstance(segmentation, StageFailure):
            return self._failed_output(frame_id, segmentation, profiler, image_path=image_path)

        with profiler.measure("landmarks"):
            landmarks, landmark_mode = self._detect_landmarks_with_fallback(
                image_bgr,
                segmentation,
                frame_id=frame_id,
            )
        if isinstance(landmarks, StageFailure):
            return self._failed_output(frame_id, landmarks, profiler, image_path=image_path)

        with profiler.measure("region_split"):
            working_roi, working_mask, working_landmarks = self._focus_roi_on_landmarks(
                segmentation.roi,
                segmentation.roi_mask,
                landmarks,
            )
            region_crops = self.region_splitter.split(
                working_roi,
                working_landmarks,
                hand_mask=working_mask,
            )
        if isinstance(region_crops, StageFailure):
            return self._failed_output(frame_id, region_crops, profiler, image_path=image_path)

        with profiler.measure("classification"):
            try:
                region_results = self.classifier.predict(region_crops)
            except Exception as exc:  # pragma: no cover
                return self._failed_output(
                    frame_id,
                    StageFailure("classification", "inference_error", {"error": str(exc)}),
                    profiler,
                    image_path=image_path,
                )

        with profiler.measure("aggregation"):
            try:
                aggregate = self.aggregator.aggregate(
                    region_results,
                    segmentation_confidence=segmentation.confidence,
                    landmark_confidence=landmarks.confidence,
                )
            except Exception as exc:  # pragma: no cover
                return self._failed_output(
                    frame_id,
                    StageFailure("aggregation", "aggregation_error", {"error": str(exc)}),
                    profiler,
                    image_path=image_path,
                )

        profiler.latencies_ms["total"] = round(sum(profiler.latencies_ms.values()), 3)
        output = PipelineOutput(
            frame_id=frame_id,
            status="processed",
            stage_latencies_ms=profiler.latencies_ms,
            source_image_path=str(image_path),
            segmentation_confidence=round(segmentation.confidence, 4),
            landmark_confidence=round(landmarks.confidence, 4),
            handedness=landmarks.handedness,
            landmark_mode=landmark_mode,
            region_results=region_results,
            aggregate=aggregate,
        )
        self.logger.log_output(output)
        return output

    def process_directory(self, input_dir: str | Path) -> list[PipelineOutput]:
        input_dir = Path(input_dir).resolve()
        outputs: list[PipelineOutput] = []
        for image_path in sorted(input_dir.rglob("*")):
            if image_path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp"}:
                continue
            outputs.append(self.process_image(image_path))
        return outputs

    def _failed_output(
        self,
        frame_id: str,
        failure: StageFailure,
        profiler: StageProfiler,
        *,
        image_path: str | Path | None = None,
    ) -> PipelineOutput:
        profiler.latencies_ms["total"] = round(sum(profiler.latencies_ms.values()), 3)
        output = PipelineOutput(
            frame_id=frame_id,
            status="unprocessable",
            stage_latencies_ms=profiler.latencies_ms,
            source_image_path=str(Path(image_path).resolve()) if image_path is not None else None,
            failure=failure,
        )
        self.logger.log_failure(
            failure.stage,
            frame_id=frame_id,
            reason=failure.reason,
            details=failure.details,
            latencies_ms=profiler.latencies_ms,
        )
        self.logger.log_output(output)
        return output

    def _detect_landmarks_with_fallback(
        self,
        image_bgr,
        segmentation: SegmentationOutput,
        *,
        frame_id: str,
    ) -> tuple[LandmarkOutput | StageFailure, str | None]:
        roi_landmarks = self.landmarker.detect(segmentation.roi, frame_id=frame_id)
        if not isinstance(roi_landmarks, StageFailure):
            return roi_landmarks, "roi"

        if not self.config.landmarks.fallback_to_full_image_on_roi_failure:
            return roi_landmarks, None

        if roi_landmarks.reason not in {
            "no_hand_landmarks",
            "low_landmark_confidence",
            "unexpected_landmark_count",
        }:
            return roi_landmarks, None

        crop_fallback = self._detect_landmarks_on_expanded_bbox_crop(
            image_bgr,
            segmentation,
            frame_id=frame_id,
        )
        if crop_fallback is not None:
            crop_landmarks, crop_mode = crop_fallback
            return crop_landmarks, crop_mode

        full_image_landmarks = self.landmarker.detect(
            image_bgr,
            frame_id=f"{frame_id}_full",
        )
        if isinstance(full_image_landmarks, StageFailure):
            return StageFailure(
                "landmarks",
                roi_landmarks.reason,
                {
                    **roi_landmarks.details,
                    "fallback_attempted": True,
                    "fallback_mode": "full_image",
                    "full_image_reason": full_image_landmarks.reason,
                    "full_image_details": full_image_landmarks.details,
                },
            ), None

        translated_landmarks, inside_count = self._translate_full_image_landmarks_to_roi(
            full_image_landmarks,
            bbox=segmentation.bbox,
            roi_shape=segmentation.roi.shape[:2],
        )
        if inside_count == 0:
            return StageFailure(
                "landmarks",
                "fallback_landmarks_outside_roi",
                {
                    "frame_id": frame_id,
                    "fallback_attempted": True,
                    "inside_roi_count": inside_count,
                    "bbox": list(segmentation.bbox),
                    "roi_shape": list(segmentation.roi.shape[:2]),
                },
            ), None

        return translated_landmarks, "full_image_fallback"

    def _detect_landmarks_on_expanded_bbox_crop(
        self,
        image_bgr,
        segmentation: SegmentationOutput,
        *,
        frame_id: str,
    ) -> tuple[LandmarkOutput, str] | None:
        crop_bbox = self._expanded_bbox(
            segmentation.bbox,
            image_shape=image_bgr.shape[:2],
            padding_ratio=self.config.landmarks.fallback_crop_padding_ratio,
        )
        x1, y1, x2, y2 = crop_bbox
        crop_height = max(0, y2 - y1)
        crop_width = max(0, x2 - x1)
        if crop_height == 0 or crop_width == 0:
            return None

        frame_height, frame_width = image_bgr.shape[:2]
        if crop_height >= frame_height and crop_width >= frame_width:
            return None

        crop_image = image_bgr[y1:y2, x1:x2].copy()
        crop_landmarks = self.landmarker.detect(
            crop_image,
            frame_id=f"{frame_id}_bbox_crop",
        )
        if isinstance(crop_landmarks, StageFailure):
            return None

        full_image_landmarks = self._translate_crop_landmarks_to_full_image(
            crop_landmarks,
            offset=(x1, y1),
        )
        translated_landmarks, inside_count = self._translate_full_image_landmarks_to_roi(
            full_image_landmarks,
            bbox=segmentation.bbox,
            roi_shape=segmentation.roi.shape[:2],
        )
        if inside_count == 0:
            return None

        return translated_landmarks, "bbox_crop_fallback"

    def _translate_full_image_landmarks_to_roi(
        self,
        full_image_landmarks: LandmarkOutput,
        *,
        bbox: tuple[int, int, int, int],
        roi_shape: tuple[int, int],
    ) -> tuple[LandmarkOutput, int]:
        x1, y1, _, _ = bbox
        roi_height, roi_width = roi_shape
        max_x = max(roi_width - 1, 0)
        max_y = max(roi_height - 1, 0)
        translated_points: list[LandmarkPoint] = []
        inside_count = 0

        for point in full_image_landmarks.points:
            local_x = point.x_px - x1
            local_y = point.y_px - y1
            if 0 <= local_x < roi_width and 0 <= local_y < roi_height:
                inside_count += 1
            clipped_x = min(max(int(local_x), 0), max_x)
            clipped_y = min(max(int(local_y), 0), max_y)
            translated_points.append(
                LandmarkPoint(
                    x=float(clipped_x / max(roi_width, 1)),
                    y=float(clipped_y / max(roi_height, 1)),
                    z=point.z,
                    x_px=clipped_x,
                    y_px=clipped_y,
                    presence=point.presence,
                    visibility=point.visibility,
                )
            )

        return (
            LandmarkOutput(
                confidence=full_image_landmarks.confidence,
                handedness=full_image_landmarks.handedness,
                points=tuple(translated_points),
                roi_shape=roi_shape,
            ),
            inside_count,
        )

    def _translate_crop_landmarks_to_full_image(
        self,
        crop_landmarks: LandmarkOutput,
        *,
        offset: tuple[int, int],
    ) -> LandmarkOutput:
        offset_x, offset_y = offset
        translated_points = tuple(
            LandmarkPoint(
                x=point.x,
                y=point.y,
                z=point.z,
                x_px=point.x_px + offset_x,
                y_px=point.y_px + offset_y,
                presence=point.presence,
                visibility=point.visibility,
            )
            for point in crop_landmarks.points
        )
        return LandmarkOutput(
            confidence=crop_landmarks.confidence,
            handedness=crop_landmarks.handedness,
            points=translated_points,
            roi_shape=crop_landmarks.roi_shape,
        )

    def _focus_roi_on_landmarks(
        self,
        roi_bgr,
        roi_mask,
        landmarks: LandmarkOutput,
    ) -> tuple:
        crop_x1, crop_y1, crop_x2, crop_y2 = self._focused_roi_bounds(
            roi_bgr.shape[:2],
            landmarks,
        )

        roi_height, roi_width = roi_bgr.shape[:2]
        if crop_x1 == 0 and crop_y1 == 0 and crop_x2 == roi_width and crop_y2 == roi_height:
            return roi_bgr, roi_mask, landmarks

        focused_roi = roi_bgr[crop_y1:crop_y2, crop_x1:crop_x2].copy()
        focused_mask = roi_mask[crop_y1:crop_y2, crop_x1:crop_x2].copy() if roi_mask is not None else None
        translated_points = tuple(
            LandmarkPoint(
                x=float((point.x_px - crop_x1) / max(crop_x2 - crop_x1, 1)),
                y=float((point.y_px - crop_y1) / max(crop_y2 - crop_y1, 1)),
                z=point.z,
                x_px=point.x_px - crop_x1,
                y_px=point.y_px - crop_y1,
                presence=point.presence,
                visibility=point.visibility,
            )
            for point in landmarks.points
        )
        focused_landmarks = LandmarkOutput(
            confidence=landmarks.confidence,
            handedness=landmarks.handedness,
            points=translated_points,
            roi_shape=(crop_y2 - crop_y1, crop_x2 - crop_x1),
        )
        return focused_roi, focused_mask, focused_landmarks

    def _focused_roi_bounds(
        self,
        roi_shape: tuple[int, int],
        landmarks: LandmarkOutput,
    ) -> tuple[int, int, int, int]:
        if not self.config.regions.focus_roi_on_landmarks:
            return (0, 0, roi_shape[1], roi_shape[0])

        roi_height, roi_width = roi_shape
        xs = [point.x_px for point in landmarks.points]
        ys = [point.y_px for point in landmarks.points]
        if not xs or not ys:
            return (0, 0, roi_width, roi_height)

        span_w = max(xs) - min(xs) + 1
        span_h = max(ys) - min(ys) + 1
        span = max(span_w, span_h)
        margin = max(
            int(round(span * self.config.regions.focus_padding_ratio)),
            int(self.config.regions.focus_min_margin_px),
        )
        crop_x1 = max(0, min(xs) - margin)
        crop_y1 = max(0, min(ys) - margin)
        crop_x2 = min(roi_width, max(xs) + margin + 1)
        crop_y2 = min(roi_height, max(ys) + margin + 1)
        return (crop_x1, crop_y1, crop_x2, crop_y2)

    def _expanded_bbox(
        self,
        bbox: tuple[int, int, int, int],
        *,
        image_shape: tuple[int, int],
        padding_ratio: float,
    ) -> tuple[int, int, int, int]:
        x1, y1, x2, y2 = bbox
        height, width = image_shape
        pad_x = int(round((x2 - x1) * padding_ratio))
        pad_y = int(round((y2 - y1) * padding_ratio))
        return (
            max(0, x1 - pad_x),
            max(0, y1 - pad_y),
            min(width, x2 + pad_x),
            min(height, y2 + pad_y),
        )
