from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import accuracy_score, balanced_accuracy_score, precision_recall_fscore_support

from .config import AggregationConfig, CalibrationConfig

REGION_NAMES = ("palm", "thumb", "index", "middle", "ring", "pinky")


class ThresholdCalibrator:
    def __init__(self, config: CalibrationConfig, aggregation: AggregationConfig) -> None:
        self.config = config
        self.aggregation = aggregation

    def calibrate(
        self,
        *,
        predictions_jsonl: str | Path,
        metadata_csv: str | Path,
        output_path: str | Path,
    ) -> dict:
        predictions = self._load_predictions(Path(predictions_jsonl).resolve())
        metadata = self._load_metadata(Path(metadata_csv).resolve())
        joined = []
        stats = {
            "total_predictions": len(predictions),
            "matched_metadata": 0,
            "evaluated_rows": 0,
            "skipped_missing_metadata": 0,
            "skipped_missing_regions": 0,
        }
        for frame_id, payload in predictions.items():
            if frame_id not in metadata:
                stats["skipped_missing_metadata"] += 1
                continue
            stats["matched_metadata"] += 1
            merged = dict(metadata[frame_id])
            merged["frame_id"] = frame_id
            region_results = payload.get("region_results", {})
            merged["region_scores"] = {
                region: float(region_results[region]["score"])
                for region in REGION_NAMES
                if region in region_results and "score" in region_results[region]
            }
            if len(merged["region_scores"]) == len(REGION_NAMES):
                joined.append(merged)
            else:
                stats["skipped_missing_regions"] += 1
        if not joined:
            raise ValueError("No overlapping predictions and metadata were found.")
        stats["evaluated_rows"] = len(joined)

        thresholds = np.arange(
            self.config.threshold_min,
            self.config.threshold_max + self.config.threshold_step,
            self.config.threshold_step,
        )

        best: dict | None = None
        best_rank: tuple[float, float, float, float] | None = None
        for min_region_score in thresholds:
            for pass_threshold in thresholds:
                evaluation = self._evaluate_thresholds(
                    joined,
                    min_region_score=float(min_region_score),
                    pass_threshold=float(pass_threshold),
                )
                objective = (
                    evaluation["overall"]["balanced_accuracy"]
                    - (self.config.disparity_penalty * evaluation["disparity"]["total"])
                )
                rank = (
                    float(objective),
                    float(evaluation["overall"]["balanced_accuracy"]),
                    float(evaluation["overall"]["f1"]),
                    -float(evaluation["disparity"]["total"]),
                )
                if best_rank is None or rank > best_rank:
                    best_rank = rank
                    best = {
                        "objective": round(objective, 6),
                        "min_region_score": round(float(min_region_score), 4),
                        "pass_threshold": round(float(pass_threshold), 4),
                        **evaluation,
                    }

        assert best is not None
        output_payload = {
            "recommended_thresholds": {
                "min_region_score": best["min_region_score"],
                "pass_threshold": best["pass_threshold"],
            },
            "objective": best["objective"],
            "calibration_data": {
                **stats,
                "threshold_values_tested": int(len(thresholds)),
                "search_grid_size": int(len(thresholds) * len(thresholds)),
                "threshold_min": round(float(self.config.threshold_min), 4),
                "threshold_max": round(float(self.config.threshold_max), 4),
                "threshold_step": round(float(self.config.threshold_step), 4),
            },
            "metrics": best["overall"],
            "subgroup_metrics": best["subgroups"],
            "disparity": best["disparity"],
        }
        Path(output_path).write_text(
            json.dumps(output_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        return output_payload

    def _load_predictions(self, path: Path) -> dict[str, dict]:
        predictions: dict[str, dict] = {}
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                payload = json.loads(line)
                predictions[payload["frame_id"]] = payload
        return predictions

    def _load_metadata(self, path: Path) -> dict[str, dict]:
        with path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            return {
                row["frame_id"]: {
                    "ground_truth": _binary_label(row["ground_truth"]),
                    "lighting_id": row.get("lighting_id", "").strip() or "unknown",
                    "camera_id": row.get("camera_id", "").strip() or "unknown",
                    "skin_tone": row.get("skin_tone", "").strip() or "unknown",
                }
                for row in reader
            }

    def _evaluate_thresholds(
        self,
        rows: list[dict],
        *,
        min_region_score: float,
        pass_threshold: float,
    ) -> dict:
        y_true: list[int] = []
        y_pred: list[int] = []
        subgroup_payloads = {
            "lighting_id": {},
            "camera_id": {},
            "skin_tone": {},
        }
        for row in rows:
            scores = row["region_scores"]
            weighted = (
                sum(scores[region] * self.aggregation.region_weights[region] for region in REGION_NAMES)
                / sum(self.aggregation.region_weights.values())
            )
            passed = weighted >= pass_threshold and min(scores.values()) >= min_region_score
            y_true.append(int(row["ground_truth"]))
            y_pred.append(int(passed))
            for key in subgroup_payloads:
                subgroup_payloads[key].setdefault(row[key], {"y_true": [], "y_pred": []})
                subgroup_payloads[key][row[key]]["y_true"].append(int(row["ground_truth"]))
                subgroup_payloads[key][row[key]]["y_pred"].append(int(passed))

        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true,
            y_pred,
            average="binary",
            zero_division=0,
        )
        subgroups = {
            key: {
                subgroup: self._metric_block(values["y_true"], values["y_pred"])
                for subgroup, values in subgroup_values.items()
            }
            for key, subgroup_values in subgroup_payloads.items()
        }
        disparity = {
            key: round(self._disparity(blocks), 4)
            for key, blocks in subgroups.items()
        }
        disparity["total"] = round(sum(disparity.values()), 4)
        return {
            "overall": {
                "n": len(y_true),
                "n_positive": int(sum(y_true)),
                "n_negative": int(len(y_true) - sum(y_true)),
                "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
                "balanced_accuracy": round(float(balanced_accuracy_score(y_true, y_pred)), 4),
                "precision": round(float(precision), 4),
                "recall": round(float(recall), 4),
                "f1": round(float(f1), 4),
            },
            "subgroups": subgroups,
            "disparity": disparity,
        }

    def _metric_block(self, y_true: list[int], y_pred: list[int]) -> dict[str, float]:
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_true,
            y_pred,
            average="binary",
            zero_division=0,
        )
        return {
            "n": len(y_true),
            "n_positive": int(sum(y_true)),
            "n_negative": int(len(y_true) - sum(y_true)),
            "accuracy": round(float(accuracy_score(y_true, y_pred)), 4),
            "balanced_accuracy": round(float(balanced_accuracy_score(y_true, y_pred)), 4),
            "precision": round(float(precision), 4),
            "recall": round(float(recall), 4),
            "f1": round(float(f1), 4),
        }

    def _disparity(self, blocks: dict[str, dict[str, float]]) -> float:
        if not blocks:
            return 0.0
        recalls = [
            metrics["recall"]
            for metrics in blocks.values()
            if int(metrics.get("n_positive", 0)) > 0
        ]
        if len(recalls) < 2:
            return 0.0
        return max(recalls) - min(recalls)


def _binary_label(value: str) -> int:
    return 1 if value.strip().lower() in {"1", "pass", "clean", "true", "yes"} else 0
