from __future__ import annotations

from .config import AggregationConfig
from .data_models import AggregatedResult, ClassificationResult


class ScoreAggregator:
    def __init__(self, config: AggregationConfig) -> None:
        self.config = config

    def aggregate(
        self,
        region_scores: dict[str, ClassificationResult],
        *,
        segmentation_confidence: float,
        landmark_confidence: float,
    ) -> AggregatedResult:
        failing_regions = tuple(
            sorted(
                region_name
                for region_name, result in region_scores.items()
                if result.score < self.config.min_region_score
            )
        )
        weight_total = sum(self.config.region_weights.values())
        weighted_scores = {
            region_name: result.score * self.config.region_weights[region_name]
            for region_name, result in region_scores.items()
        }
        overall_score = sum(weighted_scores.values()) / max(weight_total, 1e-6)
        passed = not failing_regions and overall_score >= self.config.pass_threshold

        decision_margin = (
            min(
                overall_score - self.config.pass_threshold,
                min(result.score for result in region_scores.values()) - self.config.min_region_score,
            )
            if passed
            else max(
                self.config.pass_threshold - overall_score,
                self.config.min_region_score - min(result.score for result in region_scores.values()),
            )
        )
        decision_confidence = max(0.0, min(1.0, abs(decision_margin) / 0.5))
        model_confidence = sum(result.confidence for result in region_scores.values()) / len(region_scores)
        overall_confidence = max(
            0.0,
            min(
                1.0,
                (0.35 * segmentation_confidence)
                + (0.25 * landmark_confidence)
                + (0.25 * model_confidence)
                + (0.15 * decision_confidence),
            ),
        )
        return AggregatedResult(
            passed=passed,
            overall_score=round(overall_score, 4),
            overall_confidence=round(overall_confidence, 4),
            failing_regions=failing_regions,
            weighted_scores={key: round(value, 4) for key, value in weighted_scores.items()},
            thresholds={
                "min_region_score": self.config.min_region_score,
                "pass_threshold": self.config.pass_threshold,
            },
        )
