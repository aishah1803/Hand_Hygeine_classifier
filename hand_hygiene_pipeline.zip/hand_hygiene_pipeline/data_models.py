from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class StageFailure:
    stage: str
    reason: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class LandmarkPoint:
    x: float
    y: float
    z: float
    x_px: int
    y_px: int
    presence: float | None = None
    visibility: float | None = None


@dataclass(frozen=True)
class SegmentationOutput:
    confidence: float
    class_id: int | None
    class_name: str
    bbox: tuple[int, int, int, int]
    mask: Any
    roi: Any
    roi_mask: Any


@dataclass(frozen=True)
class LandmarkOutput:
    confidence: float
    handedness: str
    points: tuple[LandmarkPoint, ...]
    roi_shape: tuple[int, int]


@dataclass(frozen=True)
class RegionCrop:
    name: str
    crop: Any
    mask: Any
    bbox: tuple[int, int, int, int]
    padded: bool
    area: int


@dataclass(frozen=True)
class ClassificationResult:
    region: str
    score: float
    confidence: float
    logit: float


@dataclass(frozen=True)
class AggregatedResult:
    passed: bool
    overall_score: float
    overall_confidence: float
    failing_regions: tuple[str, ...]
    weighted_scores: dict[str, float]
    thresholds: dict[str, float]


@dataclass(frozen=True)
class PipelineOutput:
    frame_id: str
    status: str
    stage_latencies_ms: dict[str, float]
    source_image_path: str | None = None
    segmentation_confidence: float | None = None
    landmark_confidence: float | None = None
    handedness: str | None = None
    landmark_mode: str | None = None
    region_results: dict[str, ClassificationResult] = field(default_factory=dict)
    aggregate: AggregatedResult | None = None
    failure: StageFailure | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        if self.aggregate is not None:
            payload["decision"] = "pass" if self.aggregate.passed else "fail"
        else:
            payload["decision"] = None
        return payload
