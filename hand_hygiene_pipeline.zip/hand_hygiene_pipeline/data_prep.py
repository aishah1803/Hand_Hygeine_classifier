from __future__ import annotations

import csv
import hashlib
import json
import math
import re
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

import cv2  # type: ignore
import numpy as np
from sklearn.model_selection import train_test_split

from .config import DataPrepConfig


@dataclass(frozen=True)
class DatasetRecord:
    image_path: Path
    label: str
    mask_path: Path | None = None
    split: str | None = None
    skin_tone: str | None = None
    camera_id: str | None = None
    lighting_id: str | None = None
    is_mislabeled: bool = False


@dataclass(frozen=True)
class PreparedDatasetReport:
    records_seen: int
    records_kept: int
    duplicates_removed: int
    mislabeled_removed: int
    split_counts: dict[str, int]
    skin_tone_counts: dict[str, dict[str, int]]
    warnings: tuple[str, ...]
    manifest_paths: dict[str, str]


def prepare_dataset(
    *,
    raw_dir: str | Path | None,
    output_dir: str | Path,
    config: DataPrepConfig,
    manifest_path: str | Path | None = None,
    label_studio_json: str | Path | None = None,
    image_root: str | Path | None = None,
) -> PreparedDatasetReport:
    raw_root = Path(raw_dir).resolve() if raw_dir else None
    out_root = Path(output_dir).resolve()
    records = _load_records(
        raw_root,
        manifest_path,
        label_studio_json,
        image_root,
        config.allowed_labels,
    )
    warnings: list[str] = []

    cleaned_records: list[DatasetRecord] = []
    duplicates_removed = 0
    mislabeled_removed = 0

    seen_sha: dict[str, DatasetRecord] = {}
    seen_ahash: dict[int, DatasetRecord] = {}

    for record in records:
        if record.label not in config.allowed_labels or record.is_mislabeled:
            mislabeled_removed += 1
            continue
        image = cv2.imread(str(record.image_path), cv2.IMREAD_COLOR)
        if image is None:
            warnings.append(f"Unreadable image skipped: {record.image_path}")
            mislabeled_removed += 1
            continue
        sha = _sha256(record.image_path)
        ahash = _average_hash(image)
        conflicting = seen_sha.get(sha)
        if conflicting is not None:
            duplicates_removed += 1
            if conflicting.label != record.label:
                mislabeled_removed += 1
            continue
        near_duplicate = _find_near_duplicate(
            ahash,
            seen_ahash,
            max_distance=config.duplicate_hash_distance,
        )
        if near_duplicate is not None:
            duplicates_removed += 1
            if near_duplicate.label != record.label:
                mislabeled_removed += 1
            continue
        seen_sha[sha] = record
        seen_ahash[ahash] = record
        cleaned_records.append(record)

    split_records = _split_records(cleaned_records, config, warnings)
    warnings.extend(_coverage_warnings(split_records))
    manifest_paths = _materialize_dataset(
        split_records=split_records,
        out_root=out_root,
        config=config,
        warnings=warnings,
    )
    report = PreparedDatasetReport(
        records_seen=len(records),
        records_kept=sum(len(items) for items in split_records.values()),
        duplicates_removed=duplicates_removed,
        mislabeled_removed=mislabeled_removed,
        split_counts={name: len(items) for name, items in split_records.items()},
        skin_tone_counts=_skin_tone_counts(split_records),
        warnings=tuple(warnings),
        manifest_paths={key: str(value) for key, value in manifest_paths.items()},
    )
    (out_root / "prepared_dataset_report.json").write_text(
        json.dumps(asdict(report), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return report


def _load_records(
    raw_root: Path | None,
    manifest_path: str | Path | None,
    label_studio_json: str | Path | None,
    image_root: str | Path | None,
    allowed_labels: tuple[str, ...],
) -> list[DatasetRecord]:
    if label_studio_json is not None:
        return _load_label_studio_records(
            annotation_path=Path(label_studio_json).resolve(),
            image_root=Path(image_root).resolve() if image_root else raw_root,
            allowed_labels=allowed_labels,
        )

    if manifest_path is not None:
        manifest_file = Path(manifest_path).resolve()
        with manifest_file.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            return [
                DatasetRecord(
                    image_path=_resolve_path(manifest_file.parent, row["image_path"]),
                    label=row["label"].strip().lower(),
                    mask_path=_optional_path(manifest_file.parent, row.get("mask_path")),
                    split=_optional_text(row.get("split")),
                    skin_tone=_optional_text(row.get("skin_tone")),
                    camera_id=_optional_text(row.get("camera_id")),
                    lighting_id=_optional_text(row.get("lighting_id")),
                    is_mislabeled=_parse_bool(row.get("is_mislabeled")),
                )
                for row in reader
            ]

    if raw_root is None:
        raise ValueError(
            "Pass --raw-dir, --manifest, or --label-studio-json to prepare the dataset."
        )

    records: list[DatasetRecord] = []
    for label_dir in sorted(raw_root.iterdir()):
        if not label_dir.is_dir():
            continue
        label = label_dir.name.strip().lower()
        if label not in allowed_labels:
            continue
        for image_path in sorted(label_dir.rglob("*")):
            if image_path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp"}:
                continue
            records.append(DatasetRecord(image_path=image_path, label=label))
    return records


def _load_label_studio_records(
    *,
    annotation_path: Path,
    image_root: Path | None,
    allowed_labels: tuple[str, ...],
) -> list[DatasetRecord]:
    payload = _read_json(annotation_path)
    if isinstance(payload, dict) and "tasks" in payload:
        tasks = payload["tasks"]
    elif isinstance(payload, list):
        tasks = payload
    else:
        raise ValueError(
            "Unsupported annotation payload. Expected a Label Studio JSON export."
        )

    records: list[DatasetRecord] = []
    for task in tasks:
        data = task.get("data", {})
        image_ref = (
            data.get("image")
            or data.get("img")
            or task.get("image")
            or task.get("image_path")
        )
        if not image_ref:
            continue

        image_path = _resolve_label_studio_image_path(
            str(image_ref),
            annotation_path=annotation_path,
            image_root=image_root,
        )
        annotations = task.get("annotations") or task.get("completions") or []
        if not annotations and task.get("result"):
            annotations = [{"result": task["result"]}]

        candidate_labels: list[str] = []
        for annotation in annotations:
            if annotation.get("was_cancelled"):
                continue
            for result in annotation.get("result", []):
                value = result.get("value", {})
                raw_labels = (
                    value.get("choices")
                    or value.get("labels")
                    or value.get("rectanglelabels")
                    or []
                )
                for raw_label in raw_labels:
                    normalized = _canonicalize_allowed_label(str(raw_label), allowed_labels)
                    if normalized is not None:
                        candidate_labels.append(normalized)

        if not candidate_labels:
            fallback_label = _canonicalize_allowed_label(
                str(data.get("label", "")).strip(),
                allowed_labels,
            )
            if fallback_label is not None:
                candidate_labels.append(fallback_label)

        if not candidate_labels:
            continue

        distinct_labels = sorted(set(candidate_labels))
        primary_label = distinct_labels[0]
        metadata = task.get("meta", {}) or {}
        records.append(
            DatasetRecord(
                image_path=image_path,
                label=primary_label,
                split=_optional_text(_first_value(data, metadata, "split", "dataset_split")),
                skin_tone=_optional_text(_first_value(data, metadata, "skin_tone", "skinTone")),
                camera_id=_optional_text(_first_value(data, metadata, "camera_id", "camera")),
                lighting_id=_optional_text(_first_value(data, metadata, "lighting_id", "lighting")),
                is_mislabeled=len(distinct_labels) > 1,
            )
        )
    return records


def _resolve_path(base_dir: Path, value: str) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def _read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _canonicalize_allowed_label(
    label: str,
    allowed_labels: tuple[str, ...],
) -> str | None:
    if not label.strip():
        return None
    aliases: dict[str, str] = {}
    for allowed in allowed_labels:
        aliases[_normalize_label_token(allowed)] = allowed
        aliases[_normalize_label_token(allowed.replace("_", " "))] = allowed
    normalized = _normalize_label_token(label)
    return aliases.get(normalized)


def _normalize_label_token(value: str) -> str:
    lowered = value.strip().lower()
    lowered = re.sub(r"[\s\-]+", "_", lowered)
    lowered = re.sub(r"[^a-z0-9_]+", "", lowered)
    return lowered


def _first_value(primary: dict, secondary: dict, *keys: str) -> str | None:
    for key in keys:
        if key in primary and primary[key] is not None:
            return str(primary[key])
        if key in secondary and secondary[key] is not None:
            return str(secondary[key])
    return None


def _normalized_name(value: str) -> str:
    lowered = value.strip().lower()
    lowered = re.sub(r"^[0-9a-f]{8,}-", "", lowered)
    lowered = re.sub(r"\.[a-z0-9]+$", "", lowered)
    lowered = re.sub(r"[^a-z0-9]+", "", lowered)
    return lowered


def _search_image_root(image_ref: str, image_root: Path | None) -> Path | None:
    if image_root is None or not image_root.exists():
        return None

    parsed = urlparse(image_ref)
    names_to_try = [Path(unquote(image_ref)).name]
    if parsed.path:
        names_to_try.append(Path(unquote(parsed.path)).name)

    normalized_targets = {
        _normalized_name(name) for name in names_to_try if name.strip()
    }
    if not normalized_targets:
        return None

    for candidate in image_root.rglob("*"):
        if not candidate.is_file():
            continue
        if _normalized_name(candidate.name) in normalized_targets:
            return candidate.resolve()
    return None


def _resolve_label_studio_image_path(
    image_ref: str,
    *,
    annotation_path: Path,
    image_root: Path | None,
) -> Path:
    raw = image_ref.strip()
    parsed = urlparse(raw)
    candidates: list[Path] = []

    if parsed.scheme == "file":
        candidates.append(Path(unquote(parsed.path)))
    elif raw.startswith("/data/local-files/?d="):
        local_part = unquote(raw.split("?d=", 1)[1])
        local_path = Path(local_part)
        candidates.append(local_path)
        if image_root is not None and not local_path.is_absolute():
            candidates.append(image_root / local_path)
    else:
        plain_path = Path(unquote(raw))
        candidates.append(plain_path)
        if not plain_path.is_absolute():
            candidates.append(annotation_path.parent / plain_path)
            if image_root is not None:
                candidates.append(image_root / plain_path)

        if parsed.path:
            url_path = Path(unquote(parsed.path.lstrip("/")))
            candidates.append(url_path)
            if image_root is not None:
                candidates.append(image_root / url_path)
                candidates.append(image_root / url_path.name)

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if candidate.exists():
            return candidate.resolve()

    fallback = _search_image_root(image_ref, image_root)
    if fallback is not None:
        return fallback

    raise FileNotFoundError(
        f"Could not resolve image path for '{image_ref}'. "
        "Pass --image-root if Label Studio exported non-local paths."
    )


def _optional_path(base_dir: Path, value: str | None) -> Path | None:
    if not value:
        return None
    return _resolve_path(base_dir, value)


def _optional_text(value: str | None) -> str | None:
    if value is None:
        return None
    cleaned = value.strip()
    return cleaned or None


def _parse_bool(value: str | None) -> bool:
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "y"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _average_hash(image: np.ndarray, hash_size: int = 8) -> int:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (hash_size, hash_size), interpolation=cv2.INTER_AREA)
    threshold = float(resized.mean())
    bits = 0
    for value in resized.flatten():
        bits = (bits << 1) | int(value >= threshold)
    return bits


def _find_near_duplicate(
    ahash: int,
    seen_ahash: dict[int, DatasetRecord],
    *,
    max_distance: int,
) -> DatasetRecord | None:
    for existing_hash, existing_record in seen_ahash.items():
        if bin(ahash ^ existing_hash).count("1") <= max_distance:
            return existing_record
    return None


def _split_records(
    records: list[DatasetRecord],
    config: DataPrepConfig,
    warnings: list[str],
) -> dict[str, list[DatasetRecord]]:
    if not records:
        return {"train": [], "val": [], "test": []}

    explicit_splits = {record.split for record in records if record.split}
    if explicit_splits:
        split_records = {"train": [], "val": [], "test": []}
        for record in records:
            target_split = (record.split or "train").lower()
            if target_split not in split_records:
                warnings.append(f"Unknown split '{target_split}' for {record.image_path}.")
                target_split = "train"
            split_records[target_split].append(record)
        return split_records

    stratify_keys = _build_stratify_keys(records)
    if stratify_keys is None:
        warnings.append(
            "Insufficient samples per skin-tone/label stratum; falling back to label-only stratification."
        )
        stratify_keys = [record.label for record in records]

    train_records, temp_records = train_test_split(
        records,
        test_size=(config.val_fraction + config.test_fraction),
        random_state=config.random_seed,
        stratify=stratify_keys if len(set(stratify_keys)) > 1 else None,
    )

    temp_key_source = _build_stratify_keys(temp_records)
    if temp_key_source is None:
        temp_key_source = [record.label for record in temp_records]

    val_ratio = config.val_fraction / max(config.val_fraction + config.test_fraction, 1e-6)
    val_records, test_records = train_test_split(
        temp_records,
        test_size=(1.0 - val_ratio),
        random_state=config.random_seed,
        stratify=temp_key_source if len(set(temp_key_source)) > 1 else None,
    )
    return {"train": train_records, "val": val_records, "test": test_records}


def _build_stratify_keys(records: list[DatasetRecord]) -> list[str] | None:
    keys = [f"{record.label}|{record.skin_tone or 'unknown'}" for record in records]
    counts = Counter(keys)
    if any(count < 2 for count in counts.values()):
        return None
    return keys


def _materialize_dataset(
    *,
    split_records: dict[str, list[DatasetRecord]],
    out_root: Path,
    config: DataPrepConfig,
    warnings: list[str],
) -> dict[str, Path]:
    manifest_paths: dict[str, Path] = {}
    augmentor = _build_augmentor()
    tone_counts = Counter(record.skin_tone or "unknown" for record in split_records["train"])
    max_tone_count = max(tone_counts.values()) if tone_counts else 1

    for split_name, records in split_records.items():
        manifest_path = out_root / f"{split_name}_manifest.csv"
        manifest_paths[split_name] = manifest_path
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        with manifest_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=[
                    "image_path",
                    "mask_path",
                    "label",
                    "split",
                    "skin_tone",
                    "camera_id",
                    "lighting_id",
                    "is_augmented",
                    "source_image_path",
                ],
            )
            writer.writeheader()

            for record in records:
                image = cv2.imread(str(record.image_path), cv2.IMREAD_COLOR)
                if image is None:
                    warnings.append(f"Failed to copy unreadable image {record.image_path}")
                    continue
                mask = _load_mask(record.mask_path)
                image_out, mask_out = _write_example(
                    out_root=out_root,
                    split_name=split_name,
                    label=record.label,
                    stem=record.image_path.stem,
                    image=image,
                    mask=mask,
                    extension=config.image_extension,
                )
                writer.writerow(
                    {
                        "image_path": image_out,
                        "mask_path": mask_out or "",
                        "label": record.label,
                        "split": split_name,
                        "skin_tone": record.skin_tone or "",
                        "camera_id": record.camera_id or "",
                        "lighting_id": record.lighting_id or "",
                        "is_augmented": 0,
                        "source_image_path": record.image_path,
                    }
                )

                if split_name != "train":
                    continue

                augmentation_budget = _augmentation_budget(
                    record,
                    tone_counts=tone_counts,
                    max_tone_count=max_tone_count,
                    config=config,
                )
                if augmentation_budget <= 0:
                    continue
                if augmentor is None:
                    raise RuntimeError(
                        "Albumentations is required for stage 1 augmentation. "
                        "Install it with `pip install albumentations`."
                    )
                for copy_index in range(augmentation_budget):
                    augmented = (
                        augmentor(image=image, mask=mask)
                        if mask is not None
                        else augmentor(image=image)
                    )
                    aug_image_out, aug_mask_out = _write_example(
                        out_root=out_root,
                        split_name=split_name,
                        label=record.label,
                        stem=f"{record.image_path.stem}_aug{copy_index + 1:02d}",
                        image=augmented["image"],
                        mask=augmented.get("mask"),
                        extension=config.image_extension,
                    )
                    writer.writerow(
                        {
                            "image_path": aug_image_out,
                            "mask_path": aug_mask_out or "",
                            "label": record.label,
                            "split": split_name,
                            "skin_tone": record.skin_tone or "",
                            "camera_id": record.camera_id or "",
                            "lighting_id": record.lighting_id or "",
                            "is_augmented": 1,
                            "source_image_path": record.image_path,
                        }
                    )
    return manifest_paths


def _augmentation_budget(
    record: DatasetRecord,
    *,
    tone_counts: Counter[str],
    max_tone_count: int,
    config: DataPrepConfig,
) -> int:
    base = config.augmentations_per_image
    if base <= 0:
        return 0
    tone = record.skin_tone or "unknown"
    count = max(tone_counts.get(tone, 1), 1)
    boost = int(math.ceil(max_tone_count / count))
    return min(config.max_augmented_copies, base * boost)


def _build_augmentor() -> Any | None:
    try:
        import albumentations as A  # type: ignore
    except ImportError:
        return None
    return A.Compose(
        [
            A.RandomShadow(p=0.35),
            A.GlassBlur(sigma=0.5, max_delta=2, iterations=1, p=0.20),
            A.ColorJitter(
                brightness=0.20,
                contrast=0.20,
                saturation=0.20,
                hue=0.08,
                p=0.40,
            ),
            A.ShiftScaleRotate(
                shift_limit=0.04,
                scale_limit=0.10,
                rotate_limit=15,
                border_mode=cv2.BORDER_REFLECT_101,
                p=0.50,
            ),
            A.HorizontalFlip(p=0.50),
            A.Perspective(scale=(0.02, 0.06), p=0.15),
        ]
    )


def _load_mask(mask_path: Path | None) -> np.ndarray | None:
    if mask_path is None:
        return None
    mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
    if mask is None:
        raise FileNotFoundError(f"Unable to read mask {mask_path}")
    return mask


def _write_example(
    *,
    out_root: Path,
    split_name: str,
    label: str,
    stem: str,
    image: np.ndarray,
    mask: np.ndarray | None,
    extension: str,
) -> tuple[str, str | None]:
    images_dir = out_root / "images" / split_name / label
    images_dir.mkdir(parents=True, exist_ok=True)
    image_out = images_dir / f"{stem}{extension}"
    if not cv2.imwrite(str(image_out), image):
        raise RuntimeError(f"cv2.imwrite failed for {image_out}")

    mask_out: Path | None = None
    if mask is not None:
        masks_dir = out_root / "masks" / split_name / label
        masks_dir.mkdir(parents=True, exist_ok=True)
        mask_out = masks_dir / f"{stem}.png"
        cv2.imwrite(str(mask_out), mask)
    return str(image_out), str(mask_out) if mask_out else None


def _skin_tone_counts(split_records: dict[str, list[DatasetRecord]]) -> dict[str, dict[str, int]]:
    results: dict[str, dict[str, int]] = {}
    for split_name, records in split_records.items():
        counter = Counter(record.skin_tone or "unknown" for record in records)
        results[split_name] = dict(sorted(counter.items()))
    return results


def _coverage_warnings(split_records: dict[str, list[DatasetRecord]]) -> list[str]:
    warnings: list[str] = []
    all_tones = {
        record.skin_tone or "unknown"
        for records in split_records.values()
        for record in records
    }
    if not all_tones:
        return warnings
    for split_name, records in split_records.items():
        split_tones = {record.skin_tone or "unknown" for record in records}
        missing = sorted(all_tones - split_tones)
        if missing:
            warnings.append(
                f"Split '{split_name}' is missing skin-tone groups: {', '.join(missing)}"
            )
    return warnings
