from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, TypeVar

DEFAULT_REGION_WEIGHTS = {
    "palm": 0.30,
    "thumb": 0.14,
    "index": 0.14,
    "middle": 0.14,
    "ring": 0.14,
    "pinky": 0.14,
}


@dataclass
class DataPrepConfig:
    allowed_labels: tuple[str, ...] = ("clean", "unclean")
    duplicate_hash_distance: int = 4
    train_fraction: float = 0.70
    val_fraction: float = 0.15
    test_fraction: float = 0.15
    augmentations_per_image: int = 2
    max_augmented_copies: int = 6
    random_seed: int = 13
    image_extension: str = ".jpg"


@dataclass
class SegmentationConfig:
    weights_path: str = "yolov8n-seg.pt"
    conf_threshold: float = 0.35
    iou_threshold: float = 0.45
    imgsz: int = 640
    device: str = "cpu"
    hand_class_name: str = "hand"
    hand_class_id: int | None = None
    retina_masks: bool = True
    train_epochs: int = 60
    train_batch: int = 16


@dataclass
class LandmarkConfig:
    model_asset_path: str = "models/hand_landmarker.task"
    num_hands: int = 1
    min_hand_detection_confidence: float = 0.40
    min_hand_presence_confidence: float = 0.40
    min_tracking_confidence: float = 0.40
    min_landmark_confidence: float = 0.40
    fallback_to_full_image_on_roi_failure: bool = True
    fallback_crop_padding_ratio: float = 1.0


@dataclass
class RegionSplitConfig:
    min_crop_size: int = 64
    padding_ratio: float = 0.20
    finger_width_ratio: float = 0.18
    focus_roi_on_landmarks: bool = True
    focus_padding_ratio: float = 1.0
    focus_min_margin_px: int = 64


@dataclass
class AggregationConfig:
    region_weights: dict[str, float] = field(
        default_factory=lambda: dict(DEFAULT_REGION_WEIGHTS)
    )
    min_region_score: float = 0.40
    pass_threshold: float = 0.65


@dataclass
class GelDetectionConfig:
    # Each range: [h_lo, h_hi, s_lo, s_hi, v_lo, v_hi] in HSV (H: 0-179, S/V: 0-255)
    # Defaults cover the most common UV hygiene-gel looks:
    # yellow-green fluorescence, cyan/blue-white fluorescence, and near-white glow.
    # Purple/blue skin tends to stay darker and is filtered mostly by the V threshold.
    hsv_ranges: list = field(
        default_factory=lambda: [
            [18, 55, 80, 255, 150, 255],    # yellow-green gel fluorescence
            [70, 135, 20, 220, 155, 255],   # cyan / blue-white fluorescence
            [0, 179, 0, 90, 195, 255],      # near-white glow fallback
        ]
    )
    adaptive_brightness_fallback: bool = True  # Otsu on region V channel as second pass


@dataclass
class CalibrationConfig:
    threshold_min: float = 0.30
    threshold_max: float = 0.85
    threshold_step: float = 0.01
    disparity_penalty: float = 0.10


@dataclass
class DeploymentConfig:
    target_name: str = "cpu"
    max_total_latency_ms: float = 250.0
    max_segmentation_latency_ms: float = 90.0
    max_landmark_latency_ms: float = 40.0
    max_classification_latency_ms: float = 50.0


@dataclass
class PipelineConfig:
    log_dir: str = "logs"
    prediction_log_name: str = "predictions.jsonl"
    prediction_csv_log_name: str = "predictions.csv"
    latency_log_name: str = "latency.jsonl"
    data_prep: DataPrepConfig = field(default_factory=DataPrepConfig)
    segmentation: SegmentationConfig = field(default_factory=SegmentationConfig)
    landmarks: LandmarkConfig = field(default_factory=LandmarkConfig)
    regions: RegionSplitConfig = field(default_factory=RegionSplitConfig)
    gel_detection: GelDetectionConfig = field(default_factory=GelDetectionConfig)
    aggregation: AggregationConfig = field(default_factory=AggregationConfig)
    calibration: CalibrationConfig = field(default_factory=CalibrationConfig)
    deployment: DeploymentConfig = field(default_factory=DeploymentConfig)

    @classmethod
    def from_json(cls, path: str | Path) -> "PipelineConfig":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        return _merge_dataclass(cls(), payload)

    def to_json(self, path: str | Path) -> None:
        Path(path).write_text(
            json.dumps(asdict(self), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )


T = TypeVar("T")


def _merge_dataclass(instance: T, updates: dict[str, Any]) -> T:
    values: dict[str, Any] = {}
    for field_def in fields(instance):
        current_value = getattr(instance, field_def.name)
        if field_def.name not in updates:
            values[field_def.name] = current_value
            continue
        new_value = updates[field_def.name]
        if is_dataclass(current_value) and isinstance(new_value, dict):
            values[field_def.name] = _merge_dataclass(current_value, new_value)
        else:
            values[field_def.name] = new_value
    return type(instance)(**values)
