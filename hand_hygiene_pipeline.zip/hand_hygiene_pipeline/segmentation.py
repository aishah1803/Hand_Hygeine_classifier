from __future__ import annotations

from pathlib import Path

import cv2  # type: ignore
import numpy as np

from .config import SegmentationConfig
from .data_models import SegmentationOutput, StageFailure

try:
    from ultralytics import YOLO  # type: ignore
except ImportError as exc:  # pragma: no cover
    YOLO = None  # type: ignore
    _ULTRALYTICS_IMPORT_ERROR = exc
else:
    _ULTRALYTICS_IMPORT_ERROR = None


class HandSegmenter:
    def __init__(self, config: SegmentationConfig) -> None:
        if YOLO is None:  # pragma: no cover
            raise RuntimeError(
                "Ultralytics is required for hand segmentation. "
                "Install it with `pip install ultralytics`."
            ) from _ULTRALYTICS_IMPORT_ERROR
        self.config = config
        self.model = YOLO(config.weights_path)

    def segment(self, image_bgr: np.ndarray, *, frame_id: str) -> SegmentationOutput | StageFailure:
        results = self.model.predict(
            source=image_bgr,
            imgsz=self.config.imgsz,
            conf=self.config.conf_threshold,
            iou=self.config.iou_threshold,
            device=self.config.device,
            retina_masks=self.config.retina_masks,
            verbose=False,
        )
        if not results:
            return StageFailure("segmentation", "no_result", {"frame_id": frame_id})

        result = results[0]
        if result.boxes is None or len(result.boxes) == 0 or result.masks is None:
            return StageFailure("segmentation", "no_hand_detected", {"frame_id": frame_id})

        names = result.names or getattr(self.model, "names", {})
        boxes = result.boxes
        confidences = boxes.conf.detach().cpu().numpy()
        class_ids = boxes.cls.detach().cpu().numpy().astype(int)
        candidates: list[tuple[float, int]] = []

        for index, confidence in enumerate(confidences):
            if confidence < self.config.conf_threshold:
                continue
            class_id = int(class_ids[index])
            if self._is_hand_class(class_id, names):
                candidates.append((float(confidence), index))

        if not candidates:
            best_conf = float(confidences.max()) if len(confidences) else 0.0
            return StageFailure(
                "segmentation",
                "low_confidence_or_wrong_class",
                {
                    "frame_id": frame_id,
                    "best_confidence": round(best_conf, 4),
                    "threshold": self.config.conf_threshold,
                },
            )

        confidence, best_index = max(candidates, key=lambda item: item[0])
        mask = result.masks.data[best_index].detach().cpu().numpy()
        if mask.shape[:2] != image_bgr.shape[:2]:
            mask = cv2.resize(
                mask,
                (image_bgr.shape[1], image_bgr.shape[0]),
                interpolation=cv2.INTER_NEAREST,
            )
        binary_mask = (mask > 0.5).astype(np.uint8) * 255
        ys, xs = np.where(binary_mask > 0)
        if len(xs) == 0 or len(ys) == 0:
            return StageFailure("segmentation", "empty_mask", {"frame_id": frame_id})

        x1 = max(0, int(xs.min()))
        x2 = min(image_bgr.shape[1], int(xs.max()) + 1)
        y1 = max(0, int(ys.min()))
        y2 = min(image_bgr.shape[0], int(ys.max()) + 1)
        roi = image_bgr[y1:y2, x1:x2].copy()
        roi_mask = binary_mask[y1:y2, x1:x2].copy()
        masked_roi = cv2.bitwise_and(roi, roi, mask=roi_mask)
        class_id = int(class_ids[best_index])
        return SegmentationOutput(
            confidence=confidence,
            class_id=class_id,
            class_name=str(names.get(class_id, f"class_{class_id}")),
            bbox=(x1, y1, x2, y2),
            mask=binary_mask,
            roi=masked_roi,
            roi_mask=roi_mask,
        )

    def _is_hand_class(self, class_id: int, names: dict[int, str] | dict[str, str]) -> bool:
        configured_id = self.config.hand_class_id
        if configured_id is not None and class_id == configured_id:
            return True
        class_name = str(names.get(class_id, "")).lower()
        if class_name == self.config.hand_class_name.lower():
            return True
        if len(names) == 1 and configured_id is None:
            return True
        return False


def train_hand_segmenter(
    *,
    dataset_yaml: str | Path,
    run_dir: str | Path,
    config: SegmentationConfig,
) -> None:
    if YOLO is None:  # pragma: no cover
        raise RuntimeError(
            "Ultralytics is required for segmentation training."
        ) from _ULTRALYTICS_IMPORT_ERROR
    run_dir = Path(run_dir).resolve()
    run_dir.parent.mkdir(parents=True, exist_ok=True)
    model = YOLO(config.weights_path)
    model.train(
        task="segment",
        data=str(Path(dataset_yaml).resolve()),
        epochs=config.train_epochs,
        imgsz=config.imgsz,
        batch=config.train_batch,
        device=config.device,
        project=str(run_dir.parent),
        name=run_dir.name,
    )
