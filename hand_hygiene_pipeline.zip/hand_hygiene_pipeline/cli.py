from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import PipelineConfig
from .profiling import assess_latency_budget, summarize_outputs


def main() -> int:
    parser = argparse.ArgumentParser(description="Hand hygiene classifier pipeline")
    parser.add_argument(
        "--config",
        default=None,
        help="Optional JSON config file. Defaults to built-in settings.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    prepare_parser = subparsers.add_parser("prepare-data", help="Stage 1 dataset prep")
    prepare_parser.add_argument("--raw-dir", default=None)
    prepare_parser.add_argument("--output-dir", required=True)
    prepare_parser.add_argument("--manifest", default=None)
    prepare_parser.add_argument("--label-studio-json", default=None)
    prepare_parser.add_argument("--image-root", default=None)

    extract_crops_parser = subparsers.add_parser(
        "extract-crops",
        help="Stage 1.5: run YOLO+MediaPipe+regions on a raw-image manifest to produce region crops for classifier training",
    )
    extract_crops_parser.add_argument("--manifest", required=True, help="Raw image manifest CSV (from prepare-data)")
    extract_crops_parser.add_argument("--output-dir", required=True, help="Where to write crop images and region manifest")
    extract_crops_parser.add_argument("--split", default="train", help="Split name (train / val / test)")
    extract_crops_parser.add_argument(
        "--no-fallback",
        action="store_true",
        help="Error instead of using full image when YOLO fails",
    )

    train_seg_parser = subparsers.add_parser(
        "train-segmentation",
        help="Stage 2 YOLOv8 segmentation training",
    )
    train_seg_parser.add_argument("--dataset-yaml", required=True)
    train_seg_parser.add_argument("--run-dir", required=True)

    predict_parser = subparsers.add_parser(
        "predict",
        help="Run the full multi-stage pipeline on one image or a directory",
    )
    predict_parser.add_argument("--input", required=True)
    predict_parser.add_argument("--summary-out", default=None)

    analyse_parser = subparsers.add_parser(
        "analyse",
        help="Generate confusion matrix, per-region coverage stats, and CSV export from predictions",
    )
    analyse_parser.add_argument("--predictions-jsonl", required=True, help="predictions.jsonl from a predict run")
    analyse_parser.add_argument("--metadata-csv", default=None, help="Optional CSV with ground_truth, skin_tone, lighting_id, camera_id columns")
    analyse_parser.add_argument("--output-dir", required=True, help="Directory to write analysis.json and results.csv")

    calibrate_parser = subparsers.add_parser(
        "calibrate",
        help="Stage 7 threshold calibration",
    )
    calibrate_parser.add_argument("--predictions-jsonl", required=True)
    calibrate_parser.add_argument("--metadata-csv", required=True)
    calibrate_parser.add_argument("--output", required=True)

    calibrate_gel_parser = subparsers.add_parser(
        "calibrate-gel",
        help="Interactive HSV trackbar tool to tune gel detection thresholds for your UV setup",
    )
    calibrate_gel_parser.add_argument("--image", required=True, help="Path to a UV hand image")

    derive_labels_parser = subparsers.add_parser(
        "derive-image-labels",
        help="Convert a YOLO export with Gel/Hand polygons into image-level clean/unclean labels",
    )
    derive_labels_parser.add_argument("--yolo-export", required=True, help="Folder containing classes.txt, images/, and labels/")
    derive_labels_parser.add_argument("--output-dir", required=True, help="Directory to write derived manifests and summary")
    derive_labels_parser.add_argument(
        "--split-manifest",
        default=None,
        help="Optional split manifest CSV (for example strict_split_manifest.csv) to keep only approved train/val/test images",
    )
    derive_labels_parser.add_argument(
        "--include-excluded",
        action="store_true",
        help="Include images not assigned to train/val/test by the split manifest",
    )

    visualize_parser = subparsers.add_parser(
        "visualize",
        help="Run full pipeline on one image and display/save annotated result",
    )
    visualize_parser.add_argument("--input", required=True)
    visualize_parser.add_argument("--out", default=None, help="Save annotated image to this path")
    visualize_parser.add_argument("--no-show", action="store_true", help="Don't open a window")

    args = parser.parse_args()
    config = PipelineConfig.from_json(args.config) if args.config else PipelineConfig()

    if args.command == "prepare-data":
        from .data_prep import prepare_dataset

        report = prepare_dataset(
            raw_dir=args.raw_dir,
            output_dir=args.output_dir,
            config=config.data_prep,
            manifest_path=args.manifest,
            label_studio_json=args.label_studio_json,
            image_root=args.image_root,
        )
        print(json.dumps(report.__dict__, indent=2, sort_keys=True))
        return 0

    if args.command == "extract-crops":
        from .crop_extractor import extract_crops

        region_manifest = extract_crops(
            manifest_path=args.manifest,
            output_dir=args.output_dir,
            config=config,
            split_name=args.split,
            fallback_full_image=not args.no_fallback,
        )
        print(f"Region manifest written to: {region_manifest}")
        return 0

    if args.command == "train-segmentation":
        from .segmentation import train_hand_segmenter

        train_hand_segmenter(
            dataset_yaml=args.dataset_yaml,
            run_dir=args.run_dir,
            config=config.segmentation,
        )
        return 0

    if args.command == "predict":
        from .pipeline import HandHygienePipeline

        pipeline = HandHygienePipeline(config)
        input_path = Path(args.input).resolve()
        if input_path.is_dir():
            outputs = pipeline.process_directory(input_path)
            latency_summary = summarize_outputs(outputs)
            summary = {
                "latencies": latency_summary,
                "budget_assessment": assess_latency_budget(
                    latency_summary,
                    config.deployment,
                ),
            }
            if args.summary_out:
                summary_path = Path(args.summary_out)
                summary_path.parent.mkdir(parents=True, exist_ok=True)
                summary_path.write_text(
                    json.dumps(summary, indent=2, sort_keys=True) + "\n",
                    encoding="utf-8",
                )
            print(json.dumps(summary, indent=2, sort_keys=True))
            return 0

        output = pipeline.process_image(input_path)
        print(json.dumps(output.to_dict(), indent=2, sort_keys=True))
        return 0

    if args.command == "analyse":
        from .analysis import analyse

        result = analyse(
            predictions_jsonl=args.predictions_jsonl,
            metadata_csv=args.metadata_csv,
            output_dir=args.output_dir,
        )
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0

    if args.command == "calibrate":
        from .calibration import ThresholdCalibrator

        calibrator = ThresholdCalibrator(config.calibration, config.aggregation)
        result = calibrator.calibrate(
            predictions_jsonl=args.predictions_jsonl,
            metadata_csv=args.metadata_csv,
            output_path=args.output,
        )
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0

    if args.command == "calibrate-gel":
        from .gel_detector import calibrate_gel_thresholds

        calibrate_gel_thresholds(args.image)
        return 0

    if args.command == "derive-image-labels":
        from .label_derivation import derive_image_labels_from_yolo_export

        result = derive_image_labels_from_yolo_export(
            yolo_export_dir=args.yolo_export,
            output_dir=args.output_dir,
            split_manifest_csv=args.split_manifest,
            include_excluded=args.include_excluded,
        )
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0

    if args.command == "visualize":
        from .visualize import run_visual_demo

        run_visual_demo(
            args.input,
            config,
            out_path=args.out,
            show=not args.no_show,
        )
        return 0

    return 1
