"""Stage 1.5 — Extract anatomical region crops from labelled raw images.

This bridges the gap between `prepare-data` (which outputs raw image manifests)
and `train-classifier` (which expects region-crop manifests).

For each image in a split manifest it runs:
  YOLO segmentation → MediaPipe landmarks → 6 anatomical region crops

Each crop is written to disk and recorded in a new region manifest CSV
that `train-classifier` can consume directly.

If YOLO fails (e.g. no hand detected) the raw image is used as the ROI
so the pipeline degrades gracefully on small datasets.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import cv2
import numpy as np

from .config import PipelineConfig
from .data_models import StageFailure
from .landmarks import MediaPipeHandLandmarkDetector
from .regions import AnatomicalRegionSplitter
from .segmentation import HandSegmenter


def extract_crops(
    *,
    manifest_path: str | Path,
    output_dir: str | Path,
    config: PipelineConfig,
    split_name: str = "train",
    fallback_full_image: bool = True,
) -> Path:
    """Run YOLO+MediaPipe+regions on every row in *manifest_path*.

    Writes cropped images to *output_dir*/crops/<split_name>/<label>/
    and returns the path to the new region manifest CSV.

    Parameters
    ----------
    manifest_path:
        CSV produced by `prepare-data` (columns: image_path, label, …).
    output_dir:
        Root directory where crop images and the region manifest are written.
    config:
        Full pipeline config (uses segmentation, landmarks, regions sub-configs).
    split_name:
        Used in the output folder name and manifest file name.
    fallback_full_image:
        If True, when YOLO fails the whole image is used as the hand ROI.
        Essential for small datasets where YOLO may not always fire.
    """
    manifest_path = Path(manifest_path).resolve()
    out_root = Path(output_dir).resolve()

    segmenter = HandSegmenter(config.segmentation)
    landmarker = MediaPipeHandLandmarkDetector(config.landmarks)
    splitter = AnatomicalRegionSplitter(config.regions)

    rows = _read_manifest(manifest_path)
    region_manifest_path = out_root / f"{split_name}_region_manifest.csv"
    out_root.mkdir(parents=True, exist_ok=True)

    failed = 0
    written = 0
    fieldnames = ["image_path", "label", "region", "source_image", "is_augmented"]

    with region_manifest_path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()

        for row in rows:
            image_path = Path(row["image_path"])
            label = row["label"]
            is_augmented = row.get("is_augmented", "0")

            image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
            if image_bgr is None:
                print(f"  [skip] cannot read {image_path}")
                failed += 1
                continue

            roi_bgr, roi_mask = _get_roi(
                image_bgr,
                image_path,
                segmenter,
                fallback_full_image=fallback_full_image,
            )

            lm = landmarker.detect(roi_bgr, frame_id=image_path.stem)
            if isinstance(lm, StageFailure):
                print(f"  [skip] landmarks failed ({lm.reason}) for {image_path.name}")
                failed += 1
                continue

            crops = splitter.split(roi_bgr, lm, hand_mask=roi_mask)
            if isinstance(crops, StageFailure):
                print(f"  [skip] region split failed ({crops.reason}) for {image_path.name}")
                failed += 1
                continue

            for region_name, crop_data in crops.items():
                crop_dir = out_root / "crops" / split_name / label / region_name
                crop_dir.mkdir(parents=True, exist_ok=True)
                crop_path = crop_dir / f"{image_path.stem}_{region_name}.jpg"
                cv2.imwrite(str(crop_path), crop_data.crop)
                writer.writerow({
                    "image_path": str(crop_path),
                    "label": label,
                    "region": region_name,
                    "source_image": str(image_path),
                    "is_augmented": is_augmented,
                })
                written += 1

    print(
        f"extract-crops [{split_name}]: {written} crops written, {failed} images skipped.\n"
        f"Region manifest → {region_manifest_path}"
    )
    return region_manifest_path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_roi(
    image_bgr: np.ndarray,
    image_path: Path,
    segmenter: HandSegmenter,
    *,
    fallback_full_image: bool,
):
    """Return (roi_bgr, roi_mask). Falls back to full image if YOLO fails."""
    seg = segmenter.segment(image_bgr, frame_id=image_path.stem)
    if not isinstance(seg, StageFailure):
        return seg.roi, seg.roi_mask

    if not fallback_full_image:
        raise RuntimeError(
            f"Segmentation failed ({seg.reason}) for {image_path.name} "
            "and fallback_full_image=False."
        )

    # Fallback: treat the whole image as the ROI with a full white mask
    h, w = image_bgr.shape[:2]
    full_mask = np.full((h, w), 255, dtype=np.uint8)
    print(f"  [fallback] YOLO failed ({seg.reason}), using full image for {image_path.name}")
    return image_bgr.copy(), full_mask


def _read_manifest(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))
