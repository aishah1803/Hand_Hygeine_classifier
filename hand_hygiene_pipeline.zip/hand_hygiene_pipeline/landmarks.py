from __future__ import annotations

from pathlib import Path

import cv2  # type: ignore

from .config import LandmarkConfig
from .data_models import LandmarkOutput, LandmarkPoint, StageFailure


class MediaPipeHandLandmarkDetector:
    def __init__(self, config: LandmarkConfig) -> None:
        self.config = config
        self._detector = self._create_detector()

    def _create_detector(self):
        try:
            import mediapipe as mp  # type: ignore
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError(
                "MediaPipe is required for landmark detection. "
                "Install it with `pip install mediapipe`."
            ) from exc

        model_path = Path(self.config.model_asset_path).resolve()
        if not model_path.exists():
            raise FileNotFoundError(
                f"MediaPipe hand landmarker model not found at {model_path}"
            )

        base_options = mp.tasks.BaseOptions(model_asset_path=str(model_path))
        options = mp.tasks.vision.HandLandmarkerOptions(
            base_options=base_options,
            running_mode=mp.tasks.vision.RunningMode.IMAGE,
            num_hands=self.config.num_hands,
            min_hand_detection_confidence=self.config.min_hand_detection_confidence,
            min_hand_presence_confidence=self.config.min_hand_presence_confidence,
            min_tracking_confidence=self.config.min_tracking_confidence,
        )
        return mp.tasks.vision.HandLandmarker.create_from_options(options)

    def detect(self, roi_bgr, *, frame_id: str) -> LandmarkOutput | StageFailure:
        height, width = roi_bgr.shape[:2]
        if height == 0 or width == 0:
            return StageFailure("landmarks", "empty_roi", {"frame_id": frame_id})

        import mediapipe as mp  # type: ignore

        roi_rgb = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=roi_rgb)
        result = self._detector.detect(mp_image)
        if not result.hand_landmarks:
            return StageFailure("landmarks", "no_hand_landmarks", {"frame_id": frame_id})

        best_index = 0
        best_confidence = 0.0
        for index in range(len(result.hand_landmarks)):
            confidence = self._estimate_confidence(result, index)
            if confidence > best_confidence:
                best_index = index
                best_confidence = confidence

        if best_confidence < self.config.min_landmark_confidence:
            return StageFailure(
                "landmarks",
                "low_landmark_confidence",
                {
                    "frame_id": frame_id,
                    "confidence": round(best_confidence, 4),
                    "threshold": self.config.min_landmark_confidence,
                },
            )

        points: list[LandmarkPoint] = []
        for landmark in result.hand_landmarks[best_index]:
            x_px = min(max(int(round(landmark.x * width)), 0), width - 1)
            y_px = min(max(int(round(landmark.y * height)), 0), height - 1)
            points.append(
                LandmarkPoint(
                    x=float(landmark.x),
                    y=float(landmark.y),
                    z=float(landmark.z),
                    x_px=x_px,
                    y_px=y_px,
                    presence=_optional_float(getattr(landmark, "presence", None)),
                    visibility=_optional_float(getattr(landmark, "visibility", None)),
                )
            )
        if len(points) != 21:
            return StageFailure(
                "landmarks",
                "unexpected_landmark_count",
                {"frame_id": frame_id, "count": len(points)},
            )

        handedness = "unknown"
        if result.handedness and result.handedness[best_index]:
            handedness = str(result.handedness[best_index][0].category_name).lower()

        return LandmarkOutput(
            confidence=best_confidence,
            handedness=handedness,
            points=tuple(points),
            roi_shape=(height, width),
        )

    def _estimate_confidence(self, result, index: int) -> float:
        confidences: list[float] = []
        for landmark in result.hand_landmarks[index]:
            presence = _optional_float(getattr(landmark, "presence", None))
            visibility = _optional_float(getattr(landmark, "visibility", None))
            if presence is not None:
                confidences.append(presence)
            if visibility is not None:
                confidences.append(visibility)
        if confidences:
            return float(sum(confidences) / len(confidences))
        if result.handedness and result.handedness[index]:
            return float(result.handedness[index][0].score)
        return 0.0


def _optional_float(value) -> float | None:
    if value is None:
        return None
    return float(value)
