from .config import PipelineConfig

__all__ = ["PipelineConfig", "HandHygienePipeline"]


def __getattr__(name: str):
    if name == "HandHygienePipeline":
        from .pipeline import HandHygienePipeline

        return HandHygienePipeline
    raise AttributeError(name)
