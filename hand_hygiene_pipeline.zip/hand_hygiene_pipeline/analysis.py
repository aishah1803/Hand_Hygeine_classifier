"""Result matrix and coverage analysis for the hand hygiene pipeline.

Reads the predictions JSONL produced by the pipeline and (optionally) a
ground-truth metadata CSV, then emits:
  - analysis.json  — confusion matrix, overall metrics, per-region stats,
                     subgroup breakdown, disparity
  - results.csv    — flat per-image table for external tools (Excel, pandas)

Usage (CLI)::

    python -m hand_hygiene_pipeline analyse \\
        --predictions-jsonl logs/predictions.jsonl \\
        --metadata-csv      data/metadata.csv \\
        --output-dir        reports/
"""
from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
)

REGIONS = ("palm", "thumb", "index", "middle", "ring", "pinky")
SUBGROUP_KEYS = ("skin_tone", "lighting_id", "camera_id")


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def analyse(
    *,
    predictions_jsonl: str | Path,
    metadata_csv: str | Path | None = None,
    output_dir: str | Path,
) -> dict:
    """Run full analysis and write output files.

    Returns the analysis dict (same content as analysis.json).
    """
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    predictions = _load_predictions(Path(predictions_jsonl).resolve())
    metadata = _load_metadata(Path(metadata_csv).resolve()) if metadata_csv else {}

    rows = _join(predictions, metadata)

    result: dict = {
        "n_images": len(predictions),
        "n_processed": len([p for p in predictions.values() if p.get("status") == "processed"]),
        "n_failed": len([p for p in predictions.values() if p.get("status") != "processed"]),
        "per_region_stats": _per_region_stats(rows),
    }

    if metadata:
        labelled = [r for r in rows if r.get("ground_truth") is not None]
        if labelled:
            result["supervised"] = _supervised_metrics(labelled)
        else:
            result["supervised"] = None
        result["subgroup_metrics"] = _subgroup_metrics(labelled if labelled else rows)
    else:
        result["supervised"] = None
        result["subgroup_metrics"] = {}

    # Write JSON report
    (output_dir / "analysis.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    # Write flat CSV
    _write_csv(rows, output_dir / "results.csv", has_ground_truth=bool(metadata))

    return result


# ---------------------------------------------------------------------------
# Supervised metrics (requires ground-truth labels)
# ---------------------------------------------------------------------------

def _supervised_metrics(rows: list[dict]) -> dict:
    y_true = [r["ground_truth"] for r in rows]
    y_pred = [int(r["decision"] == "pass") for r in rows]

    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="binary", zero_division=0
    )
    return {
        "confusion_matrix": {
            "TP": int(tp),
            "FP": int(fp),
            "TN": int(tn),
            "FN": int(fn),
        },
        "n_positive": int(sum(y_true)),
        "n_negative": int(len(y_true) - sum(y_true)),
        "accuracy":          round(float(accuracy_score(y_true, y_pred)), 4),
        "balanced_accuracy": round(float(balanced_accuracy_score(y_true, y_pred)), 4),
        "precision":         round(float(precision), 4),
        "recall":            round(float(recall), 4),
        "f1":                round(float(f1), 4),
        "n_labelled":        len(rows),
    }


# ---------------------------------------------------------------------------
# Per-region coverage statistics (no labels needed)
# ---------------------------------------------------------------------------

def _per_region_stats(rows: list[dict]) -> dict[str, dict[str, float]]:
    region_scores: dict[str, list[float]] = {r: [] for r in REGIONS}
    for row in rows:
        for region in REGIONS:
            val = row.get(f"{region}_score")
            if val is not None:
                region_scores[region].append(float(val))

    stats: dict[str, dict[str, float]] = {}
    for region, values in region_scores.items():
        if not values:
            continue
        arr = np.array(values)
        stats[region] = {
            "n":      len(values),
            "mean":   round(float(arr.mean()), 4),
            "std":    round(float(arr.std()), 4),
            "min":    round(float(arr.min()), 4),
            "p25":    round(float(np.percentile(arr, 25)), 4),
            "median": round(float(np.median(arr)), 4),
            "p75":    round(float(np.percentile(arr, 75)), 4),
            "max":    round(float(arr.max()), 4),
        }
    return stats


# ---------------------------------------------------------------------------
# Subgroup breakdown
# ---------------------------------------------------------------------------

def _subgroup_metrics(rows: list[dict]) -> dict:
    result = {}
    for key in SUBGROUP_KEYS:
        groups: dict[str, list[dict]] = {}
        for row in rows:
            group = str(row.get(key) or "unknown")
            groups.setdefault(group, []).append(row)
        if not groups:
            continue
        group_stats: dict[str, dict] = {}
        for group_name, group_rows in groups.items():
            entry: dict = {"n": len(group_rows)}
            labelled = [r for r in group_rows if r.get("ground_truth") is not None]
            if labelled:
                y_true = [r["ground_truth"] for r in labelled]
                y_pred = [int(r["decision"] == "pass") for r in labelled]
                precision, recall, f1, _ = precision_recall_fscore_support(
                    y_true, y_pred, average="binary", zero_division=0
                )
                entry.update({
                    "n_positive":        int(sum(y_true)),
                    "n_negative":        int(len(y_true) - sum(y_true)),
                    "accuracy":          round(float(accuracy_score(y_true, y_pred)), 4),
                    "balanced_accuracy": round(float(balanced_accuracy_score(y_true, y_pred)), 4),
                    "precision":         round(float(precision), 4),
                    "recall":            round(float(recall), 4),
                    "f1":                round(float(f1), 4),
                })
            group_stats[group_name] = entry
        # Recall disparity across groups (fairness metric)
        recalls = [
            v["recall"]
            for v in group_stats.values()
            if "recall" in v and int(v.get("n_positive", 0)) > 0
        ]
        result[key] = {
            "groups": group_stats,
            "recall_disparity": round(max(recalls) - min(recalls), 4) if len(recalls) > 1 else None,
        }
    return result


# ---------------------------------------------------------------------------
# CSV export
# ---------------------------------------------------------------------------

def _write_csv(rows: list[dict], path: Path, *, has_ground_truth: bool) -> None:
    fieldnames = [
        "frame_id",
        "status",
        "decision",
        "overall_score",
        "overall_confidence",
        *[f"{r}_score" for r in REGIONS],
        *[f"{r}_confidence" for r in REGIONS],
        "failing_regions",
        "segmentation_confidence",
        "landmark_confidence",
    ]
    if has_ground_truth:
        fieldnames += ["ground_truth", "skin_tone", "lighting_id", "camera_id"]

    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def _load_predictions(path: Path) -> dict[str, dict]:
    predictions: dict[str, dict] = {}
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            payload = json.loads(line)
            predictions[payload["frame_id"]] = payload
    return predictions


def _load_metadata(path: Path) -> dict[str, dict]:
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        return {
            row["frame_id"]: {
                "ground_truth": _binary_label(row["ground_truth"]) if "ground_truth" in row else None,
                "skin_tone":    row.get("skin_tone", "unknown").strip() or "unknown",
                "lighting_id":  row.get("lighting_id", "unknown").strip() or "unknown",
                "camera_id":    row.get("camera_id", "unknown").strip() or "unknown",
            }
            for row in reader
        }


def _join(predictions: dict[str, dict], metadata: dict[str, dict]) -> list[dict]:
    rows = []
    for frame_id, pred in predictions.items():
        row: dict = {
            "frame_id":                frame_id,
            "status":                  pred.get("status"),
            "decision":                pred.get("decision"),
            "overall_score":           pred.get("aggregate", {}).get("overall_score") if pred.get("aggregate") else None,
            "overall_confidence":      pred.get("aggregate", {}).get("overall_confidence") if pred.get("aggregate") else None,
            "failing_regions":         "|".join(pred.get("aggregate", {}).get("failing_regions", [])) if pred.get("aggregate") else None,
            "segmentation_confidence": pred.get("segmentation_confidence"),
            "landmark_confidence":     pred.get("landmark_confidence"),
        }
        for region in REGIONS:
            region_data = pred.get("region_results", {}).get(region, {})
            row[f"{region}_score"]      = region_data.get("score")
            row[f"{region}_confidence"] = region_data.get("confidence")

        if frame_id in metadata:
            row.update(metadata[frame_id])

        rows.append(row)
    return rows


def _binary_label(value: str) -> int:
    return 1 if value.strip().lower() in {"1", "pass", "clean", "true", "yes"} else 0
