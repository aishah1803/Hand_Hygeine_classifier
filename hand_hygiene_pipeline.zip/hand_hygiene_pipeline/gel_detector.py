"""UV gel fluorescence detector — Stage 5 (coverage-based).

Under UV (blacklight) illumination, hygiene gel fluoresces brightly.
Skin without gel stays dark. This module detects the glowing pixels
inside each anatomical region and returns a coverage ratio (0.0–1.0).

No training data required — the UV light does the work.

Typical gel fluorescence colours under 365 nm UV:
  - GloGerm / most hand-hygiene training gels → yellow-green
  - Some gels → blue-white
  - Skin baseline → very dark

The detector uses two strategies in order:
  1. Colour-channel thresholding in HSV (fast, tunable).
  2. Adaptive brightness fallback (when the image is already in near-greyscale).

Run the built-in calibration helper to find your exact thresholds:
    python -m hand_hygiene_pipeline calibrate-gel --image your_hand.jpg
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from .config import GelDetectionConfig
from .data_models import ClassificationResult, RegionCrop


class GelCoverageEstimator:
    """Replace the MobileNetV3 classifier with physics-based UV coverage estimation.

    For each region crop, it:
      1. Converts to HSV.
      2. Applies a two-pass threshold: strict colour match first,
         then an adaptive brightness fallback to catch edge cases.
      3. Returns coverage ratio as the classification score.
    """

    def __init__(self, config: GelDetectionConfig) -> None:
        self.config = config

    # ------------------------------------------------------------------
    # Public API  (same signature as the old ML classifier's .predict)
    # ------------------------------------------------------------------

    def predict(self, region_crops: dict[str, RegionCrop]) -> dict[str, ClassificationResult]:
        results, _ = self.predict_with_masks(region_crops)
        return results

    def predict_with_masks(
        self,
        region_crops: dict[str, RegionCrop],
    ) -> tuple[dict[str, ClassificationResult], dict[str, np.ndarray]]:
        results: dict[str, ClassificationResult] = {}
        gel_masks: dict[str, np.ndarray] = {}
        for region_name, crop in region_crops.items():
            ratio, gel_mask = self._coverage_ratio_and_mask(crop)
            # confidence: how far from the 0.5 decision boundary
            confidence = float(min(1.0, abs(ratio - 0.5) * 2.0))
            results[region_name] = ClassificationResult(
                region=region_name,
                score=round(ratio, 4),
                confidence=round(confidence, 4),
                logit=float(np.log(max(ratio, 1e-6)) - np.log(max(1.0 - ratio, 1e-6))),
            )
            gel_masks[region_name] = gel_mask
        return results, gel_masks

    # ------------------------------------------------------------------
    # Coverage detection
    # ------------------------------------------------------------------

    def _coverage_ratio(self, crop: RegionCrop) -> float:
        ratio, _ = self._coverage_ratio_and_mask(crop)
        return ratio

    def _coverage_ratio_and_mask(self, crop: RegionCrop) -> tuple[float, np.ndarray]:
        """Return fraction of region pixels that contain UV-fluorescent gel."""
        img = crop.crop
        if img is None or img.size == 0:
            return 0.0, np.zeros((0, 0), dtype=np.uint8)

        # Only evaluate pixels inside the anatomical region mask
        region_mask = crop.mask  # uint8, 0 or 255

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

        # --- pass 1: colour-based fluorescence detection ---
        gel_mask = self._hsv_threshold(hsv)

        # --- pass 2: adaptive brightness fallback ---
        # Only triggers when the colour-range pass finds very little gel,
        # e.g. when lighting shifts and the gel appears dimmer than expected.
        v_channel = hsv[:, :, 2]
        if self.config.adaptive_brightness_fallback:
            region_pixels = v_channel[region_mask > 0]
            primary_ratio = (
                float(np.count_nonzero(cv2.bitwise_and(gel_mask, region_mask)))
                / max(len(region_pixels), 1)
            )
            if primary_ratio < 0.05 and len(region_pixels) > 0 and region_pixels.std() > 15:
                # Otsu threshold computed from masked pixels only
                otsu_threshold, _ = cv2.threshold(
                    region_pixels.reshape(-1, 1).astype(np.uint8),
                    0, 255,
                    cv2.THRESH_BINARY + cv2.THRESH_OTSU,
                )
                brightness_mask = (v_channel >= int(round(float(otsu_threshold)))).astype(np.uint8) * 255
                # Apply 15% discount — lower certainty than explicit colour ranges
                otsu_gel = cv2.bitwise_and(brightness_mask, region_mask)
                otsu_ratio = float(np.count_nonzero(otsu_gel)) / max(len(region_pixels), 1)
                if otsu_ratio > primary_ratio * 1.5:
                    gel_mask = cv2.bitwise_or(gel_mask, brightness_mask)

        # --- morphological cleanup (remove speckle noise) ---
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        gel_mask = cv2.morphologyEx(gel_mask, cv2.MORPH_OPEN, kernel)

        # --- restrict to anatomical region ---
        gel_in_region = cv2.bitwise_and(gel_mask, region_mask)
        total_region_px = int(np.count_nonzero(region_mask))
        gel_px = int(np.count_nonzero(gel_in_region))

        if total_region_px == 0:
            return 0.0, gel_in_region

        return float(gel_px) / float(total_region_px), gel_in_region

    def _hsv_threshold(self, hsv: np.ndarray) -> np.ndarray:
        """Build gel mask from configured HSV ranges.

        Each range is (h_lo, h_hi, s_lo, s_hi, v_lo, v_hi).
        Multiple ranges are unioned (catches yellow-green AND blue-white gels).
        """
        combined = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for r in self.config.hsv_ranges:
            lo = np.array([r[0], r[2], r[4]], dtype=np.uint8)
            hi = np.array([r[1], r[3], r[5]], dtype=np.uint8)
            mask = cv2.inRange(hsv, lo, hi)
            combined = cv2.bitwise_or(combined, mask)
        return combined


# ---------------------------------------------------------------------------
# Calibration helper
# ---------------------------------------------------------------------------

def calibrate_gel_thresholds(image_path: str | Path) -> None:
    """Interactive HSV calibration tool.

    Opens two windows:
      - The original UV image.
      - A live preview of the gel mask with trackbar controls.

    Adjust trackbars until the gel area is highlighted cleanly,
    then note the values for your config.

    Press Q or ESC to quit and print the final values.
    """
    img = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(f"Cannot read {image_path}")

    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    window = "Gel calibration — adjust trackbars, press Q to finish"
    cv2.namedWindow(window, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(window, 900, 600)

    def nothing(_): pass

    # Defaults tuned for UV-light white/near-white gel fluorescence
    cv2.createTrackbar("H lo",  window, 0,   179, nothing)
    cv2.createTrackbar("H hi",  window, 179, 179, nothing)
    cv2.createTrackbar("S lo",  window, 0,   255, nothing)
    cv2.createTrackbar("S hi",  window, 110, 255, nothing)
    cv2.createTrackbar("V lo",  window, 190, 255, nothing)
    cv2.createTrackbar("V hi",  window, 255, 255, nothing)
    cv2.createTrackbar("Opacity", window, 60, 100, nothing)

    print("\nCalibration window open.")
    print("Adjust the H/S/V sliders until the gel is highlighted in green.")
    print("Press Q or ESC when done.\n")

    while True:
        h_lo = cv2.getTrackbarPos("H lo",  window)
        h_hi = cv2.getTrackbarPos("H hi",  window)
        s_lo = cv2.getTrackbarPos("S lo",  window)
        s_hi = cv2.getTrackbarPos("S hi",  window)
        v_lo = cv2.getTrackbarPos("V lo",  window)
        v_hi = cv2.getTrackbarPos("V hi",  window)
        opacity = cv2.getTrackbarPos("Opacity", window) / 100.0

        mask = cv2.inRange(
            hsv,
            np.array([h_lo, s_lo, v_lo], dtype=np.uint8),
            np.array([h_hi, s_hi, v_hi], dtype=np.uint8),
        )
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

        overlay = img.copy()
        overlay[mask > 0] = [0, 220, 0]  # green highlight
        preview = cv2.addWeighted(img, 1.0 - opacity, overlay, opacity, 0)

        coverage = np.count_nonzero(mask) / mask.size
        label = f"Coverage: {coverage:.1%}  |  H[{h_lo}-{h_hi}] S[{s_lo}-{s_hi}] V[{v_lo}-{v_hi}]"
        cv2.putText(preview, label, (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.65, (255, 255, 255), 2)

        cv2.imshow(window, preview)
        key = cv2.waitKey(30) & 0xFF
        if key in (ord("q"), ord("Q"), 27):
            break

    cv2.destroyAllWindows()
    print("=" * 60)
    print("Add these values to your config under 'gel_detection.hsv_ranges':")
    print(f"  [[{h_lo}, {h_hi}, {s_lo}, {s_hi}, {v_lo}, {v_hi}]]")
    print("=" * 60)
