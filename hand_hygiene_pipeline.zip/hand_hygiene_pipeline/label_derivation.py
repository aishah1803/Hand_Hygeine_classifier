from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path


def derive_image_labels_from_yolo_export(
    *,
    yolo_export_dir: str | Path,
    output_dir: str | Path,
    split_manifest_csv: str | Path | None = None,
    include_excluded: bool = False,
) -> dict:
    yolo_export_dir = Path(yolo_export_dir).resolve()
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    images_dir = yolo_export_dir / "images"
    labels_dir = yolo_export_dir / "labels"
    class_map = _load_class_map(yolo_export_dir / "classes.txt")
    split_lookup = (
        _load_split_lookup(Path(split_manifest_csv).resolve())
        if split_manifest_csv
        else {}
    )

    image_rows: list[dict[str, str | int]] = []
    skipped_rows: list[dict[str, str]] = []
    derived_label_counts: Counter[str] = Counter()

    for label_path in sorted(labels_dir.glob("*.txt")):
        image_path = _find_image(images_dir, label_path.stem)
        if image_path is None:
            skipped_rows.append(
                {
                    "image_name": f"{label_path.stem}.*",
                    "reason": "missing matching image file for label",
                }
            )
            continue

        split_name = split_lookup.get(image_path.name, "")
        if split_lookup and split_name not in {"train", "val", "test"} and not include_excluded:
            skipped_rows.append(
                {
                    "image_name": image_path.name,
                    "reason": f"excluded by split manifest ({split_name or 'no split'})",
                }
            )
            continue

        counts = _read_class_counts(label_path)
        gel_count = _count_for_names(class_map, counts, {"gel"})
        hand_count = _count_for_names(class_map, counts, {"hand"})

        derived_label = _derive_image_label(gel_count=gel_count, hand_count=hand_count)
        if derived_label is None:
            skipped_rows.append(
                {
                    "image_name": image_path.name,
                    "reason": "unable to derive clean/unclean label from annotation classes",
                }
            )
            continue

        derived_label_counts[derived_label] += 1
        image_rows.append(
            {
                "image_name": image_path.name,
                "frame_id": image_path.stem,
                "image_path": str(image_path),
                "label_path": str(label_path),
                "split": split_name,
                "label": derived_label,
                "ground_truth": derived_label,
                "gel_instances": gel_count,
                "hand_instances": hand_count,
            }
        )

    classification_manifest = output_dir / "classification_manifest.csv"
    with classification_manifest.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "image_path",
                "label",
                "split",
                "source_label_path",
                "gel_instances",
                "hand_instances",
                "is_mislabeled",
            ],
        )
        writer.writeheader()
        for row in image_rows:
            writer.writerow(
                {
                    "image_path": row["image_path"],
                    "label": row["label"],
                    "split": row["split"],
                    "source_label_path": row["label_path"],
                    "gel_instances": row["gel_instances"],
                    "hand_instances": row["hand_instances"],
                    "is_mislabeled": 0,
                }
            )

    heldout_metadata = output_dir / "heldout_metadata.csv"
    with heldout_metadata.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "frame_id",
                "ground_truth",
                "lighting_id",
                "camera_id",
                "skin_tone",
                "split",
                "image_name",
                "gel_instances",
                "hand_instances",
            ],
        )
        writer.writeheader()
        for row in image_rows:
            writer.writerow(
                {
                    "frame_id": row["frame_id"],
                    "ground_truth": row["ground_truth"],
                    "lighting_id": "",
                    "camera_id": "",
                    "skin_tone": "",
                    "split": row["split"],
                    "image_name": row["image_name"],
                    "gel_instances": row["gel_instances"],
                    "hand_instances": row["hand_instances"],
                }
            )

    skipped_manifest = output_dir / "skipped_images.csv"
    with skipped_manifest.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["image_name", "reason"])
        writer.writeheader()
        writer.writerows(skipped_rows)

    warnings: list[str] = []
    if len(derived_label_counts) < 2:
        warnings.append(
            "Derived image-level labels contain fewer than 2 classes. "
            "This dataset is not sufficient for clean-vs-unclean calibration or classifier evaluation."
        )
    if not derived_label_counts:
        warnings.append("No image-level labels were derived.")

    summary = {
        "yolo_export_dir": str(yolo_export_dir),
        "output_dir": str(output_dir),
        "split_manifest_csv": str(Path(split_manifest_csv).resolve()) if split_manifest_csv else None,
        "include_excluded": include_excluded,
        "class_map": class_map,
        "derived_image_count": len(image_rows),
        "skipped_image_count": len(skipped_rows),
        "derived_label_counts": dict(sorted(derived_label_counts.items())),
        "warnings": warnings,
        "artifacts": {
            "classification_manifest_csv": str(classification_manifest),
            "heldout_metadata_csv": str(heldout_metadata),
            "skipped_images_csv": str(skipped_manifest),
        },
    }
    (output_dir / "label_derivation_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return summary


def _load_class_map(path: Path) -> dict[int, str]:
    if not path.exists():
        raise FileNotFoundError(f"Missing classes.txt at {path}")
    with path.open("r", encoding="utf-8") as handle:
        names = [line.strip() for line in handle if line.strip()]
    return {index: name for index, name in enumerate(names)}


def _load_split_lookup(path: Path) -> dict[str, str]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return {
            row["image_name"]: row["split"]
            for row in reader
            if row.get("image_name") and row.get("split")
        }


def _find_image(images_dir: Path, stem: str) -> Path | None:
    for suffix in (".jpg", ".jpeg", ".png", ".bmp"):
        candidate = images_dir / f"{stem}{suffix}"
        if candidate.exists():
            return candidate
    return None


def _read_class_counts(path: Path) -> dict[int, int]:
    counts: Counter[int] = Counter()
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            class_id = int(line.split()[0])
            counts[class_id] += 1
    return dict(counts)


def _count_for_names(class_map: dict[int, str], counts: dict[int, int], names: set[str]) -> int:
    total = 0
    target_names = {name.lower() for name in names}
    for class_id, count in counts.items():
        class_name = class_map.get(class_id, "").strip().lower()
        if class_name in target_names:
            total += count
    return total


def _derive_image_label(*, gel_count: int, hand_count: int) -> str | None:
    if gel_count > 0:
        return "unclean"
    if hand_count > 0:
        return "clean"
    return None
