"""Visualization utilities for single-image pipeline results.

Usage:
    from hand_hygiene_pipeline.visualize import draw_result
    annotated = draw_result(image_bgr, pipeline_output, landmark_output, region_crops)
    cv2.imshow("result", annotated)
    cv2.waitKey(0)

Or via CLI:
    python -m hand_hygiene_pipeline --config default_config.json visualize \
        --input /path/to/image.jpg --out annotated.jpg
"""
from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

from .data_models import AggregatedResult, ClassificationResult, LandmarkOutput, PipelineOutput, RegionCrop

_PASS_COLOUR = (0, 200, 0)      # green (BGR)
_FAIL_COLOUR = (0, 0, 220)      # red (BGR)
_WARN_COLOUR = (0, 165, 255)    # orange (BGR)
_TEXT_COLOUR = (255, 255, 255)

_REGION_COLOURS = {
    "palm":   (255, 200,   0),
    "thumb":  (0,   200, 255),
    "index":  (200,   0, 255),
    "middle": (0,   255, 100),
    "ring":   (255,  50, 200),
    "pinky":  (50,  200, 255),
}


def draw_result(
    image_bgr: np.ndarray,
    output: PipelineOutput,
    landmark_output: LandmarkOutput | None = None,
    region_crops: dict[str, RegionCrop] | None = None,
    *,
    scale: float = 1.0,
) -> np.ndarray:
    """Return an annotated copy of *image_bgr* showing pipeline results."""
    canvas = image_bgr.copy()
    if scale != 1.0:
        h, w = canvas.shape[:2]
        canvas = cv2.resize(canvas, (int(w * scale), int(h * scale)))

    h, w = canvas.shape[:2]
    font = cv2.FONT_HERSHEY_SIMPLEX

    if output.status == "unprocessable" or output.aggregate is None:
        reason = output.failure.reason if output.failure else "unknown"
        stage = output.failure.stage if output.failure else "?"
        _banner(canvas, f"FAILED [{stage}]: {reason}", _FAIL_COLOUR)
        return canvas

    agg = output.aggregate
    decision_colour = _PASS_COLOUR if agg.passed else _FAIL_COLOUR
    decision_text = "PASS" if agg.passed else "FAIL"

    # --- top banner ---
    banner_h = 48
    cv2.rectangle(canvas, (0, 0), (w, banner_h), decision_colour, -1)
    label = (
        f"{decision_text}  score={agg.overall_score:.2f}  "
        f"conf={agg.overall_confidence:.2f}  "
        f"seg={output.segmentation_confidence:.2f}  "
        f"lm={output.landmark_confidence:.2f}"
    )
    cv2.putText(canvas, label, (8, 32), font, 0.65, _TEXT_COLOUR, 2, cv2.LINE_AA)

    # --- landmark skeleton ---
    if landmark_output is not None:
        _draw_skeleton(canvas, landmark_output, scale=scale)

    # --- per-region score sidebar ---
    if output.region_results:
        _draw_region_sidebar(canvas, output.region_results, agg)

    # --- failing regions label ---
    if agg.failing_regions:
        msg = "Low coverage: " + ", ".join(agg.failing_regions)
        cv2.putText(canvas, msg, (8, h - 12), font, 0.55, _WARN_COLOUR, 2, cv2.LINE_AA)

    return canvas


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

_CONNECTIONS = [
    (0, 1), (1, 2), (2, 3), (3, 4),        # thumb
    (0, 5), (5, 6), (6, 7), (7, 8),        # index
    (0, 9), (9, 10), (10, 11), (11, 12),   # middle
    (0, 13), (13, 14), (14, 15), (15, 16), # ring
    (0, 17), (17, 18), (18, 19), (19, 20), # pinky
    (5, 9), (9, 13), (13, 17),             # palm arch
]

_FINGER_FOR_POINT = {
    1: "thumb", 2: "thumb", 3: "thumb", 4: "thumb",
    5: "index", 6: "index", 7: "index", 8: "index",
    9: "middle", 10: "middle", 11: "middle", 12: "middle",
    13: "ring", 14: "ring", 15: "ring", 16: "ring",
    17: "pinky", 18: "pinky", 19: "pinky", 20: "pinky",
}


def _draw_skeleton(canvas: np.ndarray, lm: LandmarkOutput, scale: float) -> None:
    pts = [(int(p.x_px * scale), int(p.y_px * scale + 48)) for p in lm.points]
    for a, b in _CONNECTIONS:
        if a < len(pts) and b < len(pts):
            colour = _REGION_COLOURS.get(_FINGER_FOR_POINT.get(a, "palm"), (180, 180, 180))
            cv2.line(canvas, pts[a], pts[b], colour, 2, cv2.LINE_AA)
    for idx, pt in enumerate(pts):
        colour = _REGION_COLOURS.get(_FINGER_FOR_POINT.get(idx, "palm"), (180, 180, 180))
        cv2.circle(canvas, pt, 4, colour, -1, cv2.LINE_AA)
        cv2.circle(canvas, pt, 4, (255, 255, 255), 1, cv2.LINE_AA)


def _draw_region_sidebar(
    canvas: np.ndarray,
    region_results: dict[str, ClassificationResult],
    agg: AggregatedResult,
) -> None:
    h, w = canvas.shape[:2]
    bar_w = 160
    row_h = 26
    padding = 6
    sidebar_h = len(region_results) * row_h + 2 * padding
    x0 = w - bar_w - 4
    y0 = 56

    cv2.rectangle(canvas, (x0 - 2, y0 - 2), (w - 2, y0 + sidebar_h + 2), (30, 30, 30), -1)

    font = cv2.FONT_HERSHEY_SIMPLEX
    for row, (region, result) in enumerate(region_results.items()):
        y = y0 + padding + row * row_h + row_h // 2
        is_failing = region in agg.failing_regions
        bar_colour = _FAIL_COLOUR if is_failing else _REGION_COLOURS.get(region, (180, 180, 180))
        fill_len = int((w - bar_w + padding - (x0 + 4)) * result.score + (bar_w - 20))
        cv2.rectangle(canvas, (x0 + 4, y - 8), (x0 + 4 + fill_len, y + 10), bar_colour, -1)
        label = f"{region[:5]:5s} {result.score:.2f}"
        cv2.putText(canvas, label, (x0 + 6, y + 5), font, 0.45, _TEXT_COLOUR, 1, cv2.LINE_AA)


def _banner(canvas: np.ndarray, text: str, colour: tuple) -> None:
    h, w = canvas.shape[:2]
    cv2.rectangle(canvas, (0, 0), (w, 48), colour, -1)
    cv2.putText(canvas, text, (8, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.65, _TEXT_COLOUR, 2, cv2.LINE_AA)


# ---------------------------------------------------------------------------
# Standalone demo runner  (used by the "visualize" CLI sub-command)
# ---------------------------------------------------------------------------

def run_visual_demo(
    image_path: str | Path,
    config,
    *,
    out_path: str | Path | None = None,
    show: bool = True,
) -> np.ndarray:
    """Run the full pipeline on *image_path* and return (and optionally display/save) the annotated image."""
    import cv2 as _cv2
    from .pipeline import HandHygienePipeline
    from .data_models import StageFailure

    image_path = Path(image_path).resolve()
    image_bgr = _cv2.imread(str(image_path), _cv2.IMREAD_COLOR)
    if image_bgr is None:
        raise FileNotFoundError(f"Cannot read {image_path}")

    # Run pipeline for the structured output
    pipeline = HandHygienePipeline(config)
    output = pipeline.process_image(image_path)

    # Re-run intermediate stages to get objects for richer annotation
    landmark_output = None
    region_crops: dict[str, RegionCrop] | None = None
    if output.status == "processed":
        seg = pipeline.segmenter.segment(image_bgr, frame_id=image_path.stem)
        if not isinstance(seg, StageFailure):
            lm, _ = pipeline._detect_landmarks_with_fallback(
                image_bgr,
                seg,
                frame_id=image_path.stem,
            )
            if not isinstance(lm, StageFailure):
                focused_roi, focused_mask, focused_landmarks = pipeline._focus_roi_on_landmarks(
                    seg.roi,
                    seg.roi_mask,
                    lm,
                )
                landmark_output = focused_landmarks
                crops = pipeline.region_splitter.split(
                    focused_roi,
                    focused_landmarks,
                    hand_mask=focused_mask,
                )
                if not isinstance(crops, StageFailure):
                    region_crops = crops

    annotated = draw_result(image_bgr, output, landmark_output, region_crops)

    if out_path is not None:
        _cv2.imwrite(str(out_path), annotated)
        print(f"Saved annotated image to {out_path}")

    if show:
        _cv2.imshow("Hand Hygiene Pipeline", annotated)
        _cv2.waitKey(0)
        _cv2.destroyAllWindows()

    return annotated
