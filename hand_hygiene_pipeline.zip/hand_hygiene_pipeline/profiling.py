from __future__ import annotations

import csv
import json
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .config import DeploymentConfig
from .data_models import PipelineOutput

DOCUMENTATION_REGION_NAMES = ("palm", "thumb", "index", "middle", "ring", "pinky")
LATENCY_STAGE_NAMES = (
    "decode",
    "segmentation",
    "landmarks",
    "region_split",
    "classification",
    "aggregation",
    "total",
)


def _append_jsonl(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, sort_keys=True) + "\n")


def _append_csv_row(path: Path, fieldnames: list[str], row: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    needs_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        if needs_header:
            writer.writeheader()
        writer.writerow({name: row.get(name, "") for name in fieldnames})


def _logged_at_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _prediction_csv_fieldnames() -> list[str]:
    fieldnames = [
        "logged_at_utc",
        "frame_id",
        "source_image_path",
        "status",
        "decision",
        "passed",
        "handedness",
        "landmark_mode",
        "segmentation_confidence",
        "landmark_confidence",
        "overall_score",
        "overall_confidence",
        "failing_regions",
        "min_region_score",
        "pass_threshold",
    ]
    for region_name in DOCUMENTATION_REGION_NAMES:
        fieldnames.extend(
            [
                f"{region_name}_score",
                f"{region_name}_confidence",
                f"{region_name}_logit",
                f"{region_name}_weighted_score",
            ]
        )
    fieldnames.extend(f"{stage_name}_ms" for stage_name in LATENCY_STAGE_NAMES)
    fieldnames.extend(
        [
            "failure_stage",
            "failure_reason",
            "failure_details_json",
        ]
    )
    return fieldnames


def _flatten_output_for_csv(output: PipelineOutput, *, logged_at_utc: str) -> dict[str, object]:
    row: dict[str, object] = {
        "logged_at_utc": logged_at_utc,
        "frame_id": output.frame_id,
        "source_image_path": output.source_image_path or "",
        "status": output.status,
        "decision": output.to_dict().get("decision") or "",
        "passed": "",
        "handedness": output.handedness or "",
        "landmark_mode": output.landmark_mode or "",
        "segmentation_confidence": output.segmentation_confidence if output.segmentation_confidence is not None else "",
        "landmark_confidence": output.landmark_confidence if output.landmark_confidence is not None else "",
        "overall_score": "",
        "overall_confidence": "",
        "failing_regions": "",
        "min_region_score": "",
        "pass_threshold": "",
        "failure_stage": "",
        "failure_reason": "",
        "failure_details_json": "",
    }

    for region_name in DOCUMENTATION_REGION_NAMES:
        row[f"{region_name}_score"] = ""
        row[f"{region_name}_confidence"] = ""
        row[f"{region_name}_logit"] = ""
        row[f"{region_name}_weighted_score"] = ""

    for stage_name in LATENCY_STAGE_NAMES:
        row[f"{stage_name}_ms"] = output.stage_latencies_ms.get(stage_name, "")

    if output.aggregate is not None:
        row["passed"] = int(output.aggregate.passed)
        row["overall_score"] = output.aggregate.overall_score
        row["overall_confidence"] = output.aggregate.overall_confidence
        row["failing_regions"] = "|".join(output.aggregate.failing_regions)
        row["min_region_score"] = output.aggregate.thresholds.get("min_region_score", "")
        row["pass_threshold"] = output.aggregate.thresholds.get("pass_threshold", "")
        for region_name, weighted_score in output.aggregate.weighted_scores.items():
            if region_name in DOCUMENTATION_REGION_NAMES:
                row[f"{region_name}_weighted_score"] = weighted_score

    for region_name, result in output.region_results.items():
        if region_name not in DOCUMENTATION_REGION_NAMES:
            continue
        row[f"{region_name}_score"] = result.score
        row[f"{region_name}_confidence"] = result.confidence
        row[f"{region_name}_logit"] = result.logit

    if output.failure is not None:
        row["failure_stage"] = output.failure.stage
        row["failure_reason"] = output.failure.reason
        row["failure_details_json"] = json.dumps(output.failure.details, sort_keys=True)

    return row


class StageProfiler:
    def __init__(self) -> None:
        self.latencies_ms: dict[str, float] = {}

    @contextmanager
    def measure(self, stage_name: str) -> Iterator[None]:
        started = time.perf_counter()
        try:
            yield
        finally:
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            self.latencies_ms[stage_name] = round(elapsed_ms, 3)


class PipelineLogger:
    def __init__(
        self,
        log_dir: str | Path,
        *,
        prediction_log_name: str = "predictions.jsonl",
        prediction_csv_log_name: str = "predictions.csv",
        latency_log_name: str = "latency.jsonl",
    ) -> None:
        self.log_dir = Path(log_dir)
        self.failures_dir = self.log_dir / "failures"
        self.predictions_log = self.log_dir / prediction_log_name
        self.predictions_csv_log = self.log_dir / prediction_csv_log_name
        self.latency_log = self.log_dir / latency_log_name
        self.failures_dir.mkdir(parents=True, exist_ok=True)

    def log_failure(
        self,
        stage: str,
        *,
        frame_id: str,
        reason: str,
        details: dict,
        latencies_ms: dict[str, float] | None = None,
    ) -> None:
        _append_jsonl(
            self.failures_dir / f"{stage}.jsonl",
            {
                "frame_id": frame_id,
                "stage": stage,
                "reason": reason,
                "details": details,
                "latencies_ms": latencies_ms or {},
            },
        )

    def log_output(self, output: PipelineOutput) -> None:
        logged_at_utc = _logged_at_utc()
        payload = output.to_dict()
        payload["logged_at_utc"] = logged_at_utc
        _append_jsonl(self.predictions_log, payload)
        _append_csv_row(
            self.predictions_csv_log,
            _prediction_csv_fieldnames(),
            _flatten_output_for_csv(output, logged_at_utc=logged_at_utc),
        )
        _append_jsonl(
            self.latency_log,
            {
                "logged_at_utc": logged_at_utc,
                "frame_id": output.frame_id,
                "status": output.status,
                "stage_latencies_ms": output.stage_latencies_ms,
            },
        )


def summarize_outputs(outputs: list[PipelineOutput]) -> dict[str, dict[str, float]]:
    metrics: dict[str, list[float]] = {}
    for output in outputs:
        for stage_name, latency in output.stage_latencies_ms.items():
            metrics.setdefault(stage_name, []).append(latency)

    summary: dict[str, dict[str, float]] = {}
    for stage_name, values in metrics.items():
        ordered = sorted(values)
        count = len(ordered)
        p95_index = min(count - 1, int(round((count - 1) * 0.95)))
        summary[stage_name] = {
            "count": float(count),
            "mean_ms": round(sum(ordered) / count, 3),
            "min_ms": round(ordered[0], 3),
            "p50_ms": round(ordered[count // 2], 3),
            "p95_ms": round(ordered[p95_index], 3),
            "max_ms": round(ordered[-1], 3),
        }
    return summary


def assess_latency_budget(
    summary: dict[str, dict[str, float]],
    deployment: DeploymentConfig,
) -> dict[str, dict[str, float | bool]]:
    budgets = {
        "segmentation": deployment.max_segmentation_latency_ms,
        "landmarks": deployment.max_landmark_latency_ms,
        "classification": deployment.max_classification_latency_ms,
        "total": deployment.max_total_latency_ms,
    }
    assessment: dict[str, dict[str, float | bool]] = {}
    for stage_name, budget_ms in budgets.items():
        observed = summary.get(stage_name, {})
        p95_ms = float(observed.get("p95_ms", 0.0))
        assessment[stage_name] = {
            "budget_ms": round(budget_ms, 3),
            "observed_p95_ms": round(p95_ms, 3),
            "within_budget": p95_ms <= budget_ms,
        }
    return assessment
