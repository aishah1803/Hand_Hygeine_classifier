from __future__ import annotations

import math

import cv2  # type: ignore
import numpy as np

from .config import RegionSplitConfig
from .data_models import LandmarkOutput, RegionCrop, StageFailure

REGION_POINT_MAP = {
    "palm": (0, 1, 5, 9, 13, 17),
    "thumb": (1, 2, 3, 4),
    "index": (5, 6, 7, 8),
    "middle": (9, 10, 11, 12),
    "ring": (13, 14, 15, 16),
    "pinky": (17, 18, 19, 20),
}


class AnatomicalRegionSplitter:
    def __init__(self, config: RegionSplitConfig) -> None:
        self.config = config

    def split(
        self,
        roi_bgr: np.ndarray,
        landmark_output: LandmarkOutput,
        *,
        hand_mask: np.ndarray | None,
    ) -> dict[str, RegionCrop] | StageFailure:
        height, width = roi_bgr.shape[:2]
        points = np.array(
            [(point.x_px, point.y_px) for point in landmark_output.points],
            dtype=np.float32,
        )
        hand_scale = self._hand_scale(points)
        region_masks: dict[str, np.ndarray] = {}

        palm_polygon = cv2.convexHull(points[list(REGION_POINT_MAP["palm"])].astype(np.int32))
        region_masks["palm"] = self._polygon_mask((height, width), palm_polygon, hand_mask)

        finger_width = max(6.0, hand_scale * self.config.finger_width_ratio)
        for region_name in ("thumb", "index", "middle", "ring", "pinky"):
            region_points = points[list(REGION_POINT_MAP[region_name])]
            polygon = self._polyline_to_polygon(region_points, region_name, finger_width)
            region_masks[region_name] = self._polygon_mask((height, width), polygon, hand_mask)

        crops: dict[str, RegionCrop] = {}
        for region_name, region_mask in region_masks.items():
            if cv2.countNonZero(region_mask) == 0:
                return StageFailure(
                    "region_split",
                    "empty_region_mask",
                    {"region": region_name},
                )
            crop = self._extract_region_crop(
                roi_bgr=roi_bgr,
                region_name=region_name,
                region_mask=region_mask,
            )
            crops[region_name] = crop
        return crops

    def _polygon_mask(
        self,
        shape: tuple[int, int],
        polygon: np.ndarray,
        hand_mask: np.ndarray | None,
    ) -> np.ndarray:
        mask = np.zeros(shape, dtype=np.uint8)
        cv2.fillPoly(mask, [polygon.astype(np.int32)], 255)
        if hand_mask is not None:
            mask = cv2.bitwise_and(mask, hand_mask)
            if cv2.countNonZero(mask) == 0:
                cv2.fillPoly(mask, [polygon.astype(np.int32)], 255)
        return mask

    def _polyline_to_polygon(
        self,
        points: np.ndarray,
        region_name: str,
        base_width: float,
    ) -> np.ndarray:
        if len(points) < 2:
            return points.astype(np.int32)
        width_scale = 1.15 if region_name == "thumb" else 1.0
        start_width = base_width * width_scale
        end_width = start_width * 0.55
        left: list[np.ndarray] = []
        right: list[np.ndarray] = []
        for index, point in enumerate(points):
            if index == 0:
                tangent = points[index + 1] - point
            elif index == len(points) - 1:
                tangent = point - points[index - 1]
            else:
                tangent = points[index + 1] - points[index - 1]
            norm = tangent / max(np.linalg.norm(tangent), 1e-6)
            normal = np.array([-norm[1], norm[0]], dtype=np.float32)
            alpha = index / max(len(points) - 1, 1)
            width = start_width + (end_width - start_width) * alpha
            offset = normal * (width / 2.0)
            left.append(point + offset)
            right.append(point - offset)
        polygon = np.vstack([np.array(left), np.array(right[::-1])])
        return polygon.astype(np.int32)

    def _hand_scale(self, points: np.ndarray) -> float:
        wrist = points[0]
        middle_base = points[9]
        palm_length = float(np.linalg.norm(wrist - middle_base))
        bbox_w = float(points[:, 0].max() - points[:, 0].min())
        bbox_h = float(points[:, 1].max() - points[:, 1].min())
        return max(palm_length, 0.25 * (bbox_w + bbox_h))

    def _extract_region_crop(
        self,
        *,
        roi_bgr: np.ndarray,
        region_name: str,
        region_mask: np.ndarray,
    ) -> RegionCrop:
        ys, xs = np.where(region_mask > 0)
        x1 = int(xs.min())
        x2 = int(xs.max()) + 1
        y1 = int(ys.min())
        y2 = int(ys.max()) + 1

        width = x2 - x1
        height = y2 - y1
        target_w = max(self.config.min_crop_size, width)
        target_h = max(self.config.min_crop_size, height)
        pad_x = int(math.ceil(max(width, target_w) * self.config.padding_ratio))
        pad_y = int(math.ceil(max(height, target_h) * self.config.padding_ratio))

        desired_w = target_w + (2 * pad_x)
        desired_h = target_h + (2 * pad_y)
        center_x = (x1 + x2) / 2.0
        center_y = (y1 + y2) / 2.0
        crop_x1 = int(round(center_x - (desired_w / 2.0)))
        crop_y1 = int(round(center_y - (desired_h / 2.0)))
        crop_x2 = crop_x1 + desired_w
        crop_y2 = crop_y1 + desired_h

        pad_left = max(0, -crop_x1)
        pad_top = max(0, -crop_y1)
        pad_right = max(0, crop_x2 - roi_bgr.shape[1])
        pad_bottom = max(0, crop_y2 - roi_bgr.shape[0])
        padded = any(value > 0 for value in (pad_left, pad_top, pad_right, pad_bottom))

        if padded:
            roi_bgr = cv2.copyMakeBorder(
                roi_bgr,
                pad_top,
                pad_bottom,
                pad_left,
                pad_right,
                borderType=cv2.BORDER_REFLECT_101,
            )
            region_mask = cv2.copyMakeBorder(
                region_mask,
                pad_top,
                pad_bottom,
                pad_left,
                pad_right,
                borderType=cv2.BORDER_CONSTANT,
                value=0,
            )
            crop_x1 += pad_left
            crop_x2 += pad_left
            crop_y1 += pad_top
            crop_y2 += pad_top

        crop = roi_bgr[crop_y1:crop_y2, crop_x1:crop_x2].copy()
        crop_mask = region_mask[crop_y1:crop_y2, crop_x1:crop_x2].copy()
        masked_crop = cv2.bitwise_and(crop, crop, mask=crop_mask)
        return RegionCrop(
            name=region_name,
            crop=masked_crop,
            mask=crop_mask,
            bbox=(crop_x1, crop_y1, crop_x2, crop_y2),
            padded=padded or width < self.config.min_crop_size or height < self.config.min_crop_size,
            area=int(cv2.countNonZero(crop_mask)),
        )
